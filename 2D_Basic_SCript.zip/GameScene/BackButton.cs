﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackButton : MonoBehaviour
{
    GameMain Player;
    Animator B_BOARD, M_BOARD;
    Search search;
    Maker maker;
    public void Start()
    {
        Player = GameObject.Find("Main Camera").GetComponent<GameMain>();
        search = Player.MainSearch;
        maker = Player.MainMaker;
        //B_BOARD = GameObject.Find("B_Board").GetComponent<Animator>();
        //M_BOARD = GameObject.Find("M_Board").GetComponent<Animator>();   
    }
    public void BackTrigger()
    {
        if(search.check_button>=1)
        {
            search.closeMap();
        }
        if (maker.check_buttonM >= 1)
        {
            maker.CloseMap();
        }

        Player.plan1 = 0;
        Player.plan2 = 0;
        Player.plan3 = 0;
        Player.Checking();
        Player.Senetence.text = "계획을 모두 정하셨습으면 완료를 누르세요 ";
        
        
    }
}
