﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameMain : MonoBehaviour
{
    Animator BOOKMOVE;
    Animation CHAR_BOX_MOVE;
    Animation INVEN_BOX_MOVE;
    Animation INTRO1_BOX_MOVE;
    Animation INTRO2_BOX_MOVE;
    int Intro;
// int check1, check2, check3;
    public bool Invencheck,open,boxopen,Fadeout,PageOpen;
    public bool Introbox1, Introbox2,SceneStart;
    public int plan1,plan2,plan3;
    public int ActiveCode1, ActiveCode2, ActiveCode3, plantype;
    public int pannel;
    public IntroText INTRO;
    Image Fade;
    Color FadeColor;

    public GameObject Inventory;//가방의상태
    TabMove book; //책의 오픈상태확인
    GameObject UpButton;//오전계획
    GameObject MidButton;//오후계획
    GameObject DownButton;//야간계획
    GameObject BookButton;//완료버툰
    GameObject BackButton;//뒤로버툰
    public GameObject Up;//오전플랜
    public GameObject DBUTTON;
    GameObject Mid;//오후플랜
    GameObject Down;//야간플랜
    GameObject IntroBox;
    GameObject IntroBox2;
    GameObject CharBox;
    GameObject box;
    AudioSource sound;
    AudioSource effectsound;
    GameObject CheckA, CheckB, CheckC;
    GameObject InvenBox;
    public Text Senetence;
    public Text SenetenceHp;
    public Text SenetenceHouseHp;
    public Text SenetenceThirsty;
    public Text SenetenceHungry;
    public Text SenetenceSleep;
    public Text SenetenceDay;
    public Text SentenceIntro;
    public Text SentenceIntro2;
    public Text WaterCounter;
    public Text FoodCounter;
    public Text WoodCounter;
    public Text IronCounter;
    public Text FlashCounter;
    public Text SpannerCounter;
    public Text AxeCounter;
    public Text HammerCounter;
    public Text CorwbarCounter;
    public Text LanternCounter;
    public Text InventoryCounter;
    food Infood;
    water Inwater;
    material Woodmaterial;
    material Ironmaterial;
    ResultText ResultPage1, ResultPage2, ResultPage3, ResultPage4;
    ResultClose ClosePage;
    Status PlayerStatus;
    public box PlayerBox;
    GameObject BOOK;
     bool settingcheck;
    Slider BackSound;
    Slider EffectSound;
    Text backnum;
    Text effnum;
     GameObject settingmenu;
    public Search MainSearch;
    public Maker MainMaker;
    int FirstCheck;
    public void Start()
    {
        SceneStart= true;
        MainSearch = GameObject.Find("morning").GetComponent<Search>();
        MainMaker = GameObject.Find("Button_M_M").GetComponent<Maker>();
        Fadeout = false;
        Fade = GameObject.Find("FadeImage").GetComponent<Image>();
        FadeColor = Fade.color;
        BOOKMOVE = GameObject.Find("BookCanvas").GetComponent<Animator>();
        BackSound = GameObject.Find("BackSlider").GetComponent<Slider>();
        EffectSound = GameObject.Find("EffectSlider").GetComponent<Slider>();
        backnum = GameObject.Find("BG").GetComponent<Text>();
        effnum = GameObject.Find("Ef").GetComponent<Text>();
        settingmenu = GameObject.Find("SETBox");
        sound = GameObject.Find("SR_Piano_room").GetComponent<AudioSource>();
        effectsound = GameObject.Find("ButtonSound").GetComponent<AudioSource>();
        BackSound.value = LoadData.backgroundsound;
        EffectSound.value= LoadData.effectsound;
        settingcheck = false;
        BOOK = GameObject.Find("책");
        IntroBox = GameObject.Find("IntroduceBox");
        IntroBox2 = GameObject.Find("IntroduceBox2");
        Inventory = GameObject.Find("inventroy");
        CharBox = GameObject.Find("Player");
        box = GameObject.Find("CharBox");
        InvenBox = GameObject.Find("InvenButton");
        open = false;
        Invencheck = false;
        book = GameObject.Find("Main Camera").GetComponent<TabMove>();
        INTRO = GameObject.Find("Main Camera").GetComponent<IntroText>();
        Senetence = GameObject.Find("IntroText").GetComponent<Text>();
        SenetenceHp = GameObject.Find("HpText").GetComponent<Text>();
        SenetenceHouseHp = GameObject.Find("HouseHpText").GetComponent<Text>();
        SenetenceSleep = GameObject.Find("SleepText").GetComponent<Text>();
        SenetenceThirsty = GameObject.Find("ThirstyText").GetComponent<Text>();
        SenetenceHungry = GameObject.Find("HungryText").GetComponent<Text>();
        SenetenceDay = GameObject.Find("DayText").GetComponent<Text>();
        SentenceIntro = GameObject.Find("IntroduceText").GetComponent<Text>();
        SentenceIntro2 = GameObject.Find("IntroduceText2").GetComponent<Text>();
        WaterCounter = GameObject.Find("WaterCount").GetComponent<Text>();
        FoodCounter = GameObject.Find("FoodCount").GetComponent<Text>(); ;
        WoodCounter = GameObject.Find("WoodCount").GetComponent<Text>(); ;
        IronCounter = GameObject.Find("IronCount").GetComponent<Text>(); ;
        FlashCounter = GameObject.Find("FlashCount").GetComponent<Text>(); ; ;
        SpannerCounter = GameObject.Find("SpannerCount").GetComponent<Text>(); ; ;
        AxeCounter = GameObject.Find("AxeCount").GetComponent<Text>(); ; ;
        HammerCounter = GameObject.Find("HammerCount").GetComponent<Text>();
        CorwbarCounter = GameObject.Find("CrowCount").GetComponent<Text>();
        LanternCounter = GameObject.Find("LanternCount").GetComponent<Text>();
        InventoryCounter = GameObject.Find("InventoryCount").GetComponent<Text>();
        INTRO.Setting();
        Intro = PlayerPrefs.GetInt("Intro"); plan1 = 0; plan2 = 0; plan3 = 0;plantype = 0;
        UpButton = GameObject.Find("UpButton");
        MidButton = GameObject.Find("MidButton");
        DownButton = GameObject.Find("DownButton");
        BookButton = GameObject.Find("BookButton");
        BackButton = GameObject.Find("BackButton");
        Up = GameObject.Find("morning");
        DBUTTON = GameObject.Find("Button_M_M");
        CheckA = GameObject.Find("SCheck");
        CheckA.transform.GetChild(0).gameObject.SetActive(false);
        CheckB = GameObject.Find("MCheck");
        CheckB.transform.GetChild(0).gameObject.SetActive(false);
        CheckC = GameObject.Find("RCheck");
        CheckC.transform.GetChild(0).gameObject.SetActive(false);
        CHAR_BOX_MOVE = box.GetComponent<Animation>();
        INVEN_BOX_MOVE = GameObject.Find("INVENTORYSET").GetComponent<Animation>();
        INTRO1_BOX_MOVE = GameObject.Find("IntroduceBox").GetComponent<Animation>();
        INTRO2_BOX_MOVE = GameObject.Find("IntroduceBox2").GetComponent<Animation>();
        //BOOK.SetActive(false);
        settingmenu.SetActive(false);
        //IntroBox.SetActive(false);
        //IntroBox2.SetActive(false);
        boxopen = false;
        Up.SetActive(false);
        //Inventory.SetActive(false);
        UpButton.SetActive(false);
        MidButton.SetActive(false);
        DownButton.SetActive(false);
        BackButton.SetActive(false);
        //box.SetActive(false);
        ActiveCode1 = 0;
        ActiveCode2 = 0;
        ActiveCode3 = 0;


        FadeColor.a = 2.0f;

        Fade.color = FadeColor;
        LoadData.backgroundsound = BackSound.value;
        LoadData.effectsound = EffectSound.value;
        backnum.text = "" + (int)(LoadData.backgroundsound * 100);
        effnum.text = "" + (int)(LoadData.effectsound * 100);
        sound.volume = LoadData.backgroundsound;
        effectsound.volume = LoadData.effectsound;
        pannel = 0;
        FirstCheck = PlayerPrefs.GetInt("Intro");


        if (PlayerPrefs.GetInt("Intro")==0)//테스트시 !=0
        {
            Status PlayerStatus1 = new Status();
            PlayerStatus = PlayerStatus1;
            box PlayerBox1 = new box();
            PlayerBox1.initBox();
            PlayerBox = PlayerBox1;
        }
        else
        {
            
            Status PlayerStatus1 = new Status(1);
            PlayerStatus = PlayerStatus1;
            box PlayerBox1 = new box();
            PlayerBox1.initBox(1);
            PlayerBox = PlayerBox1;
            
            ResultPage1 = GameObject.Find("MoringResult").GetComponent<ResultText>();
            ResultPage2 = GameObject.Find("AfterResult").GetComponent<ResultText>();
            ResultPage3 = GameObject.Find("NightResult").GetComponent<ResultText>();
            ResultPage4 = GameObject.Find("AttackResult").GetComponent<ResultText>();
            ClosePage = GameObject.Find("닫기").GetComponent<ResultClose>();
            PageOpen = true;



        }
        StatusBar();
        
        

    }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.LeftAlt))
        {
            
            PlayerBox.Test();
        }

        if (Fadeout == true)
        {
            FadeColor.a += Time.deltaTime;
            
            Fade.color = FadeColor;
            if(FadeColor.a>2)
            {
                SceneFade();
            }
        }
        else if(SceneStart == true )
        {
            FadeColor.a -= Time.deltaTime;

            Fade.color = FadeColor;
            if (FadeColor.a < 0)
            {
                SceneStart = false;
                if (FirstCheck != 0)
                {
                    ResultPage1.ViewResult();

                    Invoke("DelayResult2", 0.5f);
                    Invoke("DelayResult3", 1.0f);
                    Invoke("DelayResult4", 1.5f);
                    Invoke("DelayResult5", 2.0f);
                }
            }
        }
        else
        {
            if (book.BookOpenClose == true | Invencheck == true | settingcheck == true)
            { open = true; }
            else { open = false; }

            if (Input.GetKeyDown(KeyCode.Escape) && (book.BookOpenClose == false) && (open == false) &&(PageOpen==false))
            {
                settingmenu.SetActive(true);
                settingcheck = true;
                InvenBox.SetActive(false);
                CharBox.SetActive(false);
            }
            else if (Input.GetKeyDown(KeyCode.Escape) && settingcheck == true)
            {
                settingmenu.SetActive(false);
                settingcheck = false;
                InvenBox.SetActive(true);
                CharBox.SetActive(true);

            }
            LoadData.backgroundsound = BackSound.value;
            LoadData.effectsound = EffectSound.value;
            backnum.text = "" + (int)(LoadData.backgroundsound * 100);
            effnum.text = "" + (int)(LoadData.effectsound * 100);
            sound.volume = LoadData.backgroundsound;
            effectsound.volume = LoadData.effectsound;


        }

    }

    void SceneFade()
    {
        PlayerPrefs.SetInt("ActiveCode1", ActiveCode1);
        PlayerPrefs.SetInt("ActiveCode2", ActiveCode2);
        PlayerPrefs.SetInt("ActiveCode3", ActiveCode3);
        PlayerStatus.SaveStatus();
        PlayerBox.SaveBox();
        SceneManager.LoadScene("Loading");
    }
    public void OKButton()
    {
        effectsound.Play();
        {
            if (ActiveCode1 >= 1 & ActiveCode2 >= 1 & ActiveCode3 >= 1)
            {

                Fadeout = true;

            }
            
            if (Intro != 1)
            {
                Intro = INTRO.NextFunctionIntro();

            }

            else if (Intro == 1 & plan1 == 0 & plan2 == 0 & plan3 == 0)
            {
                if (ActiveCode1 == 0 | ActiveCode2 == 0 | ActiveCode3 == 0)
                    Senetence.text = "계획이 모두 정해지지 않았습니다";
                else
                    Senetence.text = "계획을 모두 정하셨습으면 완료를 누르세요 ";

                UpButton.SetActive(true);
                MidButton.SetActive(true);
                DownButton.SetActive(true);
                BookButton.SetActive(true);
                BackButton.SetActive(false);
                
                Up.SetActive(false);
            }
            if (Intro == 1 & plan1 == 1 & plan2 == 0 & plan3 == 0)
            {
                UpButton.SetActive(false);
                MidButton.SetActive(false);
                DownButton.SetActive(false);
                BookButton.SetActive(false);
                BackButton.SetActive(true);
                Up.SetActive(true);
                plantype = 1;
                Senetence.text = "오전계획입니다";
            }
            else if (Intro == 1 & plan2 == 1 & plan1 == 0 & plan3 == 0)
            {
                UpButton.SetActive(false);
                MidButton.SetActive(false);
                DownButton.SetActive(false);
                BookButton.SetActive(false);
                BackButton.SetActive(true);
                Up.SetActive(true);
                plantype = 2;
                Senetence.text = "오후계획입니다";
            }
            else if (Intro == 1 & plan3 == 1 & plan2 == 0 & plan1 == 0)
            {
                UpButton.SetActive(false);
                MidButton.SetActive(false);
                DownButton.SetActive(false);
                BookButton.SetActive(false);
                BackButton.SetActive(true);
                Up.SetActive(true);
                plantype = 3;
                Senetence.text = "야간계획입니다";

            }

        }


    }
    public void Checking()
    {
        effectsound.Play();
        
        {
       
            if (Intro != 1)
            {
                Intro = INTRO.NextFunctionIntro();

            }

            else if (Intro == 1 & plan1 == 0 & plan2 == 0 & plan3 == 0)
            {
                if (ActiveCode1 == 0| ActiveCode2 == 0| ActiveCode3 == 0)
                    Senetence.text = "계획이 모두 정해지지 않았습니다"; 
                else
                    Senetence.text = "계획을 모두 정하셨습으면 완료를 누르세요 ";
                Up.SetActive(false);
                UpButton.SetActive(true);
                MidButton.SetActive(true);
                DownButton.SetActive(true);
                BookButton.SetActive(true);
                BackButton.SetActive(false);
                
            }
            if (Intro == 1 & plan1 == 1 & plan2 == 0 & plan3 == 0)
            {
                UpButton.SetActive(false);
                MidButton.SetActive(false);
                DownButton.SetActive(false);
                BookButton.SetActive(false);
                BackButton.SetActive(true);
                Up.SetActive(true);
                plantype = 1;
                Senetence.text = "오전계획입니다";
            }
            else if (Intro == 1 & plan2 == 1 & plan1 == 0 & plan3 == 0)
            {
                UpButton.SetActive(false);
                MidButton.SetActive(false);
                DownButton.SetActive(false);
                BookButton.SetActive(false);
                BackButton.SetActive(true);
                Up.SetActive(true);
                plantype = 2;
                Senetence.text = "오후계획입니다";
            }
            else if (Intro == 1 & plan3 == 1 & plan2 == 0 & plan1 == 0)
            {
                UpButton.SetActive(false);
                MidButton.SetActive(false);
                DownButton.SetActive(false);
                BookButton.SetActive(false);
                BackButton.SetActive(true);
                Up.SetActive(true);
                plantype = 3;
                Senetence.text = "야간계획입니다";
                
            }

        }
        


    }
    public void OpenInvenroy()
    {
        effectsound.Play();
        if (open == false& Invencheck==false & PageOpen==false)
        {
            OpenChar2();
            //Inventory.SetActive(true);
            INVEN_BOX_MOVE.Play("DOWN_INVEN");
            CharBox.SetActive(false);
            Invencheck = true;
            WaterCounter.text = "x" + PlayerBox.ReturnWater();
            FoodCounter.text = "x" + PlayerBox.ReturnFood();
            WoodCounter.text = "x" + PlayerBox.ReturnWood();
            IronCounter.text = "x" + PlayerBox.ReturnIron();

            if (PlayerBox.ReturnFlash() >= 1)
                FlashCounter.text = "보유중";
            else
                FlashCounter.text = "미보유";
            if (PlayerBox.ReturnSpanner() >= 1)
                SpannerCounter.text = "보유중";
            else
                SpannerCounter.text = "미보유";
            if (PlayerBox.ReturnAxe() >= 1)
                AxeCounter.text = "보유중";
            else
                AxeCounter.text = "미보유";
            if (PlayerBox.ReturnHammer() >= 1)
                HammerCounter.text = "보유중";
            else
                HammerCounter.text = "미보유";
            if (PlayerBox.ReturnCrowbar() >= 1)
                CorwbarCounter.text = "보유중";
            else
                CorwbarCounter.text = "미보유";
            if (PlayerBox.ReturnLantern() >= 1)
                LanternCounter.text = "보유중";
            else
                LanternCounter.text = "미보유";
            if (PlayerBox.ReturnInventory() >= 1)
                InventoryCounter.text = "보유중";
            else
                InventoryCounter.text = "미보유";
        }
        else if (open == true & Invencheck == true)
        {
            CloseChar2();
            INVEN_BOX_MOVE.Play("UP_INVEN");
            if (Introbox1 == true)
            {
                INTRO1_BOX_MOVE.Play("ITEM_RIGHT1");
                Introbox1 = false;
            }
            if (Introbox2 == true)
            {
                INTRO2_BOX_MOVE.Play("ITEM_RIGHT2");
                Introbox2 = false;
            }
            CharBox.SetActive(true);
            Invencheck = false;
            //IntroBox.SetActive(false);
            boxopen = false;
        }
    }

    public void OpenChar()
    {
        effectsound.Play();
        if (open == false & Invencheck == false)
        {
            box.SetActive(true);
            InvenBox.SetActive(false);
            Invencheck = true;

        }
        else if (open == true & Invencheck == true)
        {
            box.SetActive(false);
            InvenBox.SetActive(true);
            Invencheck = false;
        }
    }
    public void OpenChar2()
    {
        //effectsound.Play();

        
        CHAR_BOX_MOVE.Play("DOWN_CHAR");

        Invencheck = true;


    }
    public void CloseChar2()
    {

        CHAR_BOX_MOVE.Play("UP_CHAR");

        Invencheck = false;

    }

    public void CheckMarker1()
    {
        CheckA.transform.GetChild(0).gameObject.SetActive(true);
    }
    public void CheckMarker2()
    {
        CheckB.transform.GetChild(0).gameObject.SetActive(true);
    }
    public void CheckMarker3()
    {
        CheckC.transform.GetChild(0).gameObject.SetActive(true);
    }


    void StatusBar()
    {
        HpBar();
        HouseHpBar();
        SleepBar();
        ThirstyBar();
        HungryBar();
        DayBar();
    }
    void HpBar()
    {
        SenetenceHp.text = "체력 " + PlayerStatus.ReturnHp() + "/" + PlayerStatus.ReturnMAXHp();   
    }
    void HouseHpBar()
    {
        SenetenceHouseHp.text = "건물 " + PlayerStatus.ReturnHouseHp() + "/" + PlayerStatus.ReturnHouseMAXHp();
    }
    void SleepBar()
    {
        SenetenceSleep.text = "수면 " + PlayerStatus.ReturnSleep() + "/" + PlayerStatus.ReturnMAXSleep();
    }
    void ThirstyBar()
    {
        SenetenceThirsty.text = "갈증 " + PlayerStatus.ReturnThirsty() + "/" + PlayerStatus.ReturnMAXThirsty();
    }
    void HungryBar()
    {
        SenetenceHungry.text = "허기 " + PlayerStatus.ReturnHungry() + "/" + PlayerStatus.ReturnMAXHungry();
    }
    void DayBar()
    {
        SenetenceDay.text = "날짜 : " + PlayerStatus.ReturnDay()+"일";
    }


    public void Introboxbutton(int a)
    {
        effectsound.Play();
        if (Introbox2 == true)
        {
            INTRO2_BOX_MOVE.Play("ITEM_RIGHT2");
            Introbox2 = false;
        }

        Introbox1 = true;
        INTRO1_BOX_MOVE.Play("ITEM_LEFT1");
        
            boxopen = true;
            if (a == 1)
            {
                SentenceIntro.text = "물입니다.\n물을 사용하면 갈증을 20 회복합니다.";
            }
            else if (a == 2)
            {
                SentenceIntro.text = "음식입니다.\n음식을 사용하면 허기를 20 회복합니다.";
            }
        
    }
    public void Introboxbutton2(int a)
    {
           effectsound.Play();
        if (Introbox1 == true)
        {
            INTRO1_BOX_MOVE.Play("ITEM_RIGHT1");
            Introbox1 = false;
        }
        INTRO2_BOX_MOVE.Play("ITEM_LEFT2");
        Introbox2 = true;
        boxopen = true;
            if (a == 3)
            {
                SentenceIntro2.text = "돈입니다.\n건물수리를하면 건물내구도를 100회복합니다";
            }
            else if (a == 4)
            {
                SentenceIntro2.text = "광석입니다.\n건물수리를하면 건물내구도를 300회복합니다";
            }
            else if (a == 5)
            {
                SentenceIntro2.text = "고급스태프입니다.\n야간에 탐색시 보정을 올려줍니다.(대)\n"
                + "던전 지역 탐색시 획득가능";
            }
            else if (a == 6)
            {
                SentenceIntro2.text = "단검입니다.\n건물 수리시 건물회복량을 50 올려줍니다.\n"
                +"골드 3개로 구매가능";
            }
            else if (a == 7)
            {
            SentenceIntro2.text = "도끼입니다.\n탐색시 탐색결과에 보정을 올려줍니다.(소)\n"
                + "탐색시 받는피해가 감소합니다.\n"
                +"골드5개 광물2개로 제작가능";
            }
            else if (a == 8)
            {
                SentenceIntro2.text = "망치입니다.\n건물 보수시 건물 내구도회복량을 100올려줍니다.\n"
                + "골드8개와 광석3개로 제작가능";
            }
            else if (a == 9)
            {
                SentenceIntro2.text = "스태프입니다.\n야간에 탐색시 보정을 올려줍니다.(소)\n"
                + "골드3개와 광물4개로 제작가능";
            }
            else if (a == 10)
            {
                SentenceIntro2.text = "대검입니다.\n탐색시 탐색시 보정을 올려줍니다.(중)\n"
                + "골드5개와 광물7개로 제작가능";
            }
        else if (a == 11)
        {
            SentenceIntro2.text = "가방입니다.\n탐색시 탐색결과에 보정을 올려줍니다.(중)\n"
            + "숲 지역 탐색시 획득가능";
        }

    }
    public void CancleButton()
    {
        effectsound.Play();
        if(Introbox1 == true)
        {
            INTRO1_BOX_MOVE.Play("ITEM_RIGHT1");
            Introbox1 = false;
        }
        IntroBox2.SetActive(false);
        boxopen = false;
    }
    public void UseButtons(int a)
    {
        effectsound.Play();
        if (a == 1)
        {
            if (PlayerBox.ReturnWater() >= 1 & PlayerStatus.ReturnThirsty()<100)
            {
                PlayerStatus.Thirstycalculate(20);
                PlayerBox.Watercal(-1);
                ThirstyBar();
                WaterCounter.text = "x" + PlayerBox.ReturnWater();
                
            }
        }
        else if (a == 2)
        {
            if (PlayerBox.ReturnFood() >= 1 & PlayerStatus.ReturnHungry() < 100)
            {
                PlayerStatus.Hungrycalculate(20);
                PlayerBox.Foodcal(-1);
                HungryBar();
                FoodCounter.text = "x" + PlayerBox.ReturnFood();
            }
        }
    }

    public void ExitGame()
    {
        effectsound.Play();
        Application.Quit();
    }
    public void OpenBOOK() 
    {
        BOOKMOVE.SetFloat("OUT", 1.0f);
        BOOKMOVE.SetFloat("IN", 0.0f);
    }
    public void CloseBOOK() 
    {
        BOOKMOVE.SetFloat("OUT", 0.0f);
        BOOKMOVE.SetFloat("IN", 1.0f);
    }
    void DelayResult2()
    {


        ResultPage2.ViewResult();

    }
    void DelayResult3()
    {


        ResultPage3.ViewResult();

    }
    void DelayResult4()
    {

        
        ResultPage4.ViewResult();
    }
    void DelayResult5()
    {
        ClosePage.INMOVECloseBUtton();
    }
}