﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class GameMainManager : MonoBehaviour
{
    public int PlaceCode;
    public int GenderCode;
    public int DispositionCode;
    public int BodyCode;
    public int MoneyCode;
    
    void Start()
    {

        PlaceCode = 1;//PlayerPrefs.GetInt("PlaceCode");// 1집 2일터 3벙커
        
          GenderCode = 1;//PlayerPrefs.GetInt("GenderCode");      //  1남자  2여자
        DispositionCode = 1;//PlayerPrefs.GetInt("DispositionCode");  // 1선 2중립 3악
        BodyCode = 1;//PlayerPrefs.GetInt("BodyCode"); //1마름 2뚱뚱함 3근육질
        MoneyCode = 1;//PlayerPrefs.GetInt("MoneyCode");  //1빈곤함 2평범  3부유함

        //PlayerInfo Player_Info = new PlayerInfo(PlaceCode, GenderCode, DispositionCode, BodyCode, MoneyCode);
    }

}
/*
public class PlayerInfo
{
    public int PlaceCode;
    public int GenderCode;
    public int DispositionCode;
    public int BodyCode;
    public int MoneyCode;
    public PlayerInfo(int P,int G, int D, int B, int M)
    {
    PlaceCode=P;
    GenderCode=G;
    DispositionCode=D;
    BodyCode=B;
    MoneyCode=M;
}
}
*/


