﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class IntroText : MonoBehaviour
{
    public GameMainManager Player;
    
    int Intro;
    public Text Senetence;
    public int numbering;
    string active,result,time,item;
    public int NextFunctionIntro()
    {
        if (PlayerPrefs.GetInt("Intro") == 0)
            TextFunction();
        else if (PlayerPrefs.GetInt("Intro") == 2)
            ResultFunction();
        return PlayerPrefs.GetInt("Intro");
    }
    public void Setting()
    {
        active = result = time = "";
        Intro = PlayerPrefs.GetInt("Intro");
        Senetence = GameObject.Find("IntroText").GetComponent<Text>();
        Player = GameObject.Find("Main Camera").GetComponent<GameMainManager>();
        numbering = 1;

        if (Intro == 0)
        {
           
            Senetence.text = "게임을 시작한것을 환영합니다..";
        }
        else
        {
            Senetence.text = "당신은 다음날을 맞이했습니다.";
        }
    }
    void TextFunction()
    {
        numbering += 1;
        switch (numbering)
        {
            case 1:
                Senetence.text = "지금 당신은 전염병에 의해 격리 구역안에 갖혀 있습니다 \n" +
                "이 전염병은 공기로 전염되지않고 체액으로 교환되지만" +
                "감염증상으로 매우 흉포해 집니다";
                break;
            case 2:
                Senetence.text = "Tap버툰으로 일지를 닫을 수 있습니다.\n"
                + "게임의 진행은 일지로 오늘의 일정을 정하고 진행 할 수있습니다.";
                break;
            case 3:
                Senetence.text = "일정은 크게 사냥 수리/상점 휴식이 있습니다\n" +
                    "사냥은 플레이어가 밖에서 아이템을 찾으러갈 수 있습니다\n" +
                    "수리/상점은 아이템을 사러가거나 거점을 수리할 수 있습니다.\n" +
                    "휴식는 플레이어가 밖에 나가지 않고 플레이어의 회복에 전념합니다.";
                break;
            case 4:
                Senetence.text = "설명은 끝났습니다 최대한 살아남으시오.\n";
                PlayerPrefs.SetInt("Intro", 1);

                break;
        }

    }
    void ResultFunction()
    {
        numbering += 1;
        //Senetence.text = "당신은 다음날을 맞이했습니다.";
        switch(numbering)
        {
            case 2:
                checkword(LoadData.PLANcode1,LoadData.Result1);
                TextReturn1();
                break;
            case 3:
                checkword(LoadData.PLANcode2, LoadData.Result2);
                TextReturn2();
                
                break;
            case 4:
                checkword(LoadData.PLANcode3, LoadData.Result3);

                TextReturn3();
                break;
            case 5:
                TextReturn4();

                PlayerPrefs.SetInt("Intro", 1);
                break;
            case 6:
                PlayerPrefs.SetInt("Intro", 1);
                break;



        }


    }
    void checkword(int a,int b)
    {
        switch (a)
        {
            case 1: active = "평원사냥"; break;
            case 2: active = "숲사냥"; break;
            case 3: active = "던전사냥"; break;
            case 4: active = "건물수리"; break;
            case 5: active = "상점"; break;
            case 6: active = "휴식"; break;
            default: break;

        }
        switch (b)
        {
            case 0: result = "실패"; break;
            case 1: result = "성공"; break;
            case 2: result = "대성공"; break;
            case 4: result = ""; break;
            default:result = "?"; break;

        }
    }
   string TextReturn1()
    {
        switch (numbering)
        {
            case 2: time = "오전계획"; break;
            case 3: time = "오후계획"; break;
            case 4: time = "야간계획"; break;
            default: break;

        }
        if (LoadData.GetF1 == 1)
        {
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                  + LoadData.Water1 + "개의 물을얻었고\n"
                  + LoadData.Food1 + "개의 식량을얻었고\n"
                  + LoadData.Wood1 + "개의 골드를얻었고\n"
                  + LoadData.Iron1 + "개의 광물을얻었습니다\n"
                  + "고급스태프을 획득했습니다.";
                LoadData.GetF1 = 0;
        }
        else if (LoadData.GetI1 == 1)

        {
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                  + LoadData.Water1 + "개의 물을얻었고\n"
                  + LoadData.Food1 + "개의 식량을얻었고\n"
                  + LoadData.Wood1 + "개의 골드를얻었고\n"
                  + LoadData.Iron1 + "개의 광물을얻었습니다\n"
                  + "가방을 획득했습니다.";
            LoadData.GetI1 = 0;
        }
        else if (LoadData.PLANcode1 == 1 | LoadData.PLANcode1 == 2 | LoadData.PLANcode1 == 3)
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                + LoadData.Water1 + "개의 물을얻었고\n"
                + LoadData.Food1 + "개의 식량을얻었고\n"
                + LoadData.Wood1 + "개의 골드를얻었고\n"
                + LoadData.Iron1 + "개의 광물을얻었습니다\n";


        else if (LoadData.PLANcode1 == 4)
        {
            Senetence.text = "당신은" + time + "에서 건물 수리를 하여 하단의 결과를 얻었습니다\n"
                + LoadData.Repair1 + "만큼 건물 내구도를 수리했습니다\n";
            ;
        }
    
        else if (LoadData.PLANcode1 == 5)
        {
            switch (LoadData.Make1)
            {
                case 1: item = "단검"; break;
                case 2: item = "도끼"; break;
                case 3: item = "해머"; break;
                case 5: item = "스태프"; break;
                case 6: item = "대검"; break;
                default: break;

            }
            if (LoadData.Make1 == 4)
            {
                Senetence.text = "당신은 "+time+"에서 상점에서 아무것도 사오지 못했습니다.";
            }
            else
                Senetence.text = "당신은" + time + "에서" + item + "을 사왓습니다.";

        }
        else
            Senetence.text = "당신은" + time + "에서 충분히 쉬었습니다";
        return Senetence.text;
    }
    string TextReturn2()
    {
        switch (numbering)
        {
            case 2: time = "오전계획"; break;
            case 3: time = "오후계획"; break;
            case 4: time = "야간계획"; break;
            default: break;

        }
        if (LoadData.GetF2 == 1)

        {
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                  + LoadData.Water2 + "개의 물을얻었고\n"
                  + LoadData.Food2 + "개의 식량을얻었고\n"
                  + LoadData.Wood2 + "개의 골드를얻었고\n"
                  + LoadData.Iron2 + "개의 광물을얻었습니다\n"
                  + "고급스태프을 획득했습니다.";
            LoadData.GetF2 = 0;
        }
        else if (LoadData.GetI2 == 1)

        {
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                  + LoadData.Water2 + "개의 물을얻었고\n"
                  + LoadData.Food2 + "개의 식량을얻었고\n"
                  + LoadData.Wood2 + "개의 골드를얻었고\n"
                  + LoadData.Iron2 + "개의 광물을얻었습니다\n"
                  + "가방을 획득했습니다.";
            LoadData.GetI2 = 0;
        }
        else if (LoadData.PLANcode2 == 1 | LoadData.PLANcode2 == 2 | LoadData.PLANcode2 == 3)
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                + LoadData.Water2 + "개의 물을얻었고\n"
                + LoadData.Food2 + "개의 식량을얻었고\n"
                + LoadData.Wood2 + "개의 골드를얻었고\n"
                + LoadData.Iron2 + "개의 광물을얻었습니다\n";

        else if (LoadData.PLANcode2 == 4)
        {
            Senetence.text = "당신은" + time + "에서 건물 수리를 하여 하단의 결과를 얻었습니다\n"
                + LoadData.Repair2 + "만큼 건물 내구도를 수리했습니다\n";
            ;
        }
        else if (LoadData.PLANcode2 == 5)
        {
            switch (LoadData.Make2)
            {
                case 1: item = "단검"; break;
                case 2: item = "도끼"; break;
                case 3: item = "해머"; break;
                case 5: item = "스태프"; break;
                case 6: item = "대검"; break;
                default: break;

            }
            if (LoadData.Make2 == 4)
            {
                Senetence.text = "당신은 " + time + "에서 상점에서 아무것도 사오지 못했습니다.";
            }
            else
                Senetence.text = "당신은" + time + "에서" + item + "을 사왓습니다.";

        }
        else
            Senetence.text = "당신은" + time + "에서 충분히 쉬었습니다";
        return Senetence.text;
    }
    string TextReturn3()
    {
        switch (numbering)
        {
            case 2: time = "오전계획"; break;
            case 3: time = "오후계획"; break;
            case 4: time = "야간계획"; break;
            default: break;

        }
        if (LoadData.GetF3 == 1)

        {
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                  + LoadData.Water3 + "개의 물을얻었고\n"
                  + LoadData.Food3 + "개의 식량을얻었고\n"
                  + LoadData.Wood3 + "개의 골드를얻었고\n"
                  + LoadData.Iron3 + "개의 광물을얻었습니다\n"
                  + "고급스태프을 획득했습니다.";
            LoadData.GetF3 = 0;
        }
        else if (LoadData.GetI3 == 1)

        {
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                  + LoadData.Water3 + "개의 물을얻었고\n"
                  + LoadData.Food3 + "개의 식량을얻었고\n"
                  + LoadData.Wood3 + "개의 골드를얻었고\n"
                  + LoadData.Iron3 + "개의 광물을얻었습니다\n"
                  + "가방을 획득했습니다.";
            LoadData.GetI3 = 0;
        }
        else if (LoadData.PLANcode3 == 1 | LoadData.PLANcode3 == 2 | LoadData.PLANcode3 == 3)
            Senetence.text = "당신은" + time + "에서 " + result + "하여 하단의 결과를 얻었습니다\n"
                + LoadData.Water3 + "개의 물을얻었고\n"
                + LoadData.Food3 + "개의 식량을얻었고\n"
                + LoadData.Wood3 + "개의 나무를얻었고\n"
                + LoadData.Iron3 + "개의 광물을얻었습니다\n";

        else if (LoadData.PLANcode3 == 4)
        {
            Senetence.text = "당신은" + time + "에서 건물 수리를 하여 하단의 결과를 얻었습니다\n"
                + LoadData.Repair3 + "만큼 건물 내구도를 수리했습니다\n";
            ;
        }
        else if (LoadData.PLANcode3 == 5)
        {
            switch (LoadData.Make3)
            {
                case 1: item = "단검"; break;
                case 2: item = "도끼"; break;
                case 3: item = "해머"; break;
                case 5: item = "스태프"; break;
                case 6: item = "대검"; break;
                default: break;

            }
            if (LoadData.Make3 == 4)
            {
                Senetence.text = "당신은 " + time + "에서 상점에서 아무것도 사오지 못했습니다.";
            }
            else
                Senetence.text = "당신은" + time + "에서" + item + "을 사왓습니다.";

        }
        else
            Senetence.text = "당신은" + time + "에서 충분히 쉬었습니다";
        return Senetence.text;
    }

    void TextReturn4()
    {
        if (LoadData.BA == 1)
        {
            Senetence.text = "당신은 야간습격에서 플레이어는" + LoadData.Damage1 + "만큼 피해를입고\n"
        + "건물에" + LoadData.Damage2 + "만큼 피해를 입었습니다.\n" + "당신의 도끼가 망가졌습니다.";
            LoadData.BA = 0;
        }
        else if (LoadData.BC == 1)
        {
            Senetence.text = "당신은 야간습격에서 플레이어는" + LoadData.Damage1 + "만큼 피해를입고\n"
        + "건물에" + LoadData.Damage2 + "만큼 피해를 입었습니다.\n" + "당신의 대검이 망가졌습니다.";
            LoadData.BC = 0;
        }
        else if (LoadData.BF == 1)
        {
            Senetence.text = "당신은 야간습격에서 플레이어는" + LoadData.Damage1 + "만큼 피해를입고\n"
        + "건물에" + LoadData.Damage2 + "만큼 피해를 입었습니다.\n" + "당신의 고급스태프가 망가졌습니다.";
            LoadData.BF = 0;
        }
        else if (LoadData.BH == 1)
        {
            Senetence.text = "당신은 야간습격에서 플레이어는" + LoadData.Damage1 + "만큼 피해를입고\n"
        + "건물에" + LoadData.Damage2 + "만큼 피해를 입었습니다.\n" + "당신의 해머가 망가졌습니다.";
            LoadData.BH = 0;
        }
        else if (LoadData.BI == 1)
        {
            Senetence.text = "당신은 야간습격에서 플레이어는" + LoadData.Damage1 + "만큼 피해를입고\n"
        + "건물에" + LoadData.Damage2 + "만큼 피해를 입었습니다.\n" + "당신의 가방이 망가졌습니다.";
            LoadData.BI = 0;
        }
        else if (LoadData.BL == 1)
        {
            Senetence.text = "당신은 야간습격에서 플레이어는" + LoadData.Damage1 + "만큼 피해를입고\n"
        + "건물에" + LoadData.Damage2 + "만큼 피해를 입었습니다.\n" + "당신의 스태프가 망가졌습니다.";
            LoadData.BL = 0;
        }
        else if (LoadData.BS == 1)
        {
            Senetence.text = "당신은 야간습격에서 플레이어는" + LoadData.Damage1 + "만큼 피해를입고\n"
        + "건물에" + LoadData.Damage2 + "만큼 피해를 입었습니다.\n" + "당신의 단검이 망가졌습니다.";
            LoadData.BS = 0;
        }
        else
            Senetence.text = "당신은 야간습격에서 플레이어는" + LoadData.Damage1 + "만큼 피해를입고\n"
        + "건물에" + LoadData.Damage2 + "만큼 피해를 입었습니다.";
    }
}
