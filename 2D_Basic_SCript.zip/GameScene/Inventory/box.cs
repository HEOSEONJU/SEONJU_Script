﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class box : MonoBehaviour
{
    int water;
    int food;
    int wood;
    int iron;
    int Flash;
    int Spanner;
    int Axe;
    int Hammer;
    int Lantern;
    int Crowbar;
    int Inventory;

    public void  initBox()
    {
        water = 0;
        food = 0;
        wood = 0;
        iron = 0;
        Flash = 0;
        Spanner = 0;
        Axe = 0;
        Hammer = 0;
        Lantern = 0;
        Crowbar = 0;
        Inventory = 0;

    }

    public void initBox(int a)
    {
        water = PlayerPrefs.GetInt("Water");
        food = PlayerPrefs.GetInt("Food");
        wood = PlayerPrefs.GetInt("Wood");
        iron = PlayerPrefs.GetInt("Iron");
        Flash = PlayerPrefs.GetInt("Flash");
        Spanner = PlayerPrefs.GetInt("Spanner");
        Axe = PlayerPrefs.GetInt("Axe");
        Hammer = PlayerPrefs.GetInt("Hammer");
        Lantern = PlayerPrefs.GetInt("Lantern");
        Crowbar = PlayerPrefs.GetInt("Crowbar");
        Inventory = PlayerPrefs.GetInt("Inventory");
    }
    public void SaveBox()
    {
        PlayerPrefs.SetInt("Water", water);
        PlayerPrefs.SetInt("Food", food);
        PlayerPrefs.SetInt("Wood", wood);
        PlayerPrefs.SetInt("Iron", iron);
        PlayerPrefs.SetInt("Flash", Flash);
        PlayerPrefs.SetInt("Spanner", Spanner);
        PlayerPrefs.SetInt("Axe", Axe);
        PlayerPrefs.SetInt("Hammer", Hammer);
        PlayerPrefs.SetInt("Crowbar", Crowbar);
        PlayerPrefs.SetInt("Lantern", Lantern);
        PlayerPrefs.SetInt("Inventory", Inventory);

    }

    public void Test()
    {
        water = 100;
        food = 100;
        wood = 100;
        iron = 100;

    }


    public int ReturnWater()
    {
        return water;
    }
    public int ReturnFood()
    {
        return food;
    }
    public int ReturnWood()
    {
        return wood;
    }
    public int ReturnIron()
    {
        return iron;
    }
    public int ReturnFlash()
    {
        return Flash;
    }
    public int ReturnSpanner()
    {
        return Spanner;
    }
    public int ReturnAxe()
    {
        return Axe;
    }
    public int ReturnHammer()
    {
        return Hammer;
    }
    public int ReturnLantern()
    {
        return Lantern;
    }
    public int ReturnCrowbar()
    {
        return Crowbar;
    }
    public int ReturnInventory()
    {
        return Inventory;
    }

    public void Watercal(int a)
    {
        water += a;
    }
    public void Foodcal(int a)
    {
        food += a;
    }
    public void Woodcal(int a)
    {
        wood += a;
    }
    public void Ironcal(int a)
    {
        iron += a;
    }
    public void Flashcal(int a)
    {
        Flash +=a;
    }
    public void Spannercal(int a)
    {
        Spanner += a;
    }
    public void Axecal(int a)
    {
        Axe += a;
    }
    public void Hammercal(int a)
    {
        Hammer += a;
    }
    public void Lanterncal(int a)
    {
        Lantern += a;
    }
    public void Crwobarcal(int a)
    {
        Crowbar += a;
    }
    
    public void Inventorycal(int a)
    {
        Inventory += a;
    }
}
