﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackHouse : MonoBehaviour
{
    public GameObject House;
    SpriteRenderer Antic1, Antic2;
    SpriteRenderer HouseSide1, HouseSide2;
    SpriteRenderer HouseFornt1, HouseFornt2, HouseFornt3;
    SpriteRenderer Window1, Window2, Window3;
    SpriteRenderer Beam1, Beam2, Beam3, Beam4, Beam5, Beam6, Beam7, Beam8, Beam9, Beam10, Beam11, Beam12, Beam13, Beam14;
    SpriteRenderer Door1;
    SpriteRenderer RoofWood1, RoofWood2;
    
    Color Red=  Color.red;
    Color White=Color.white;
    public void Start()
    {
        
        Antic1 = House.transform.GetChild(0).GetComponent<SpriteRenderer>();
        Antic2 = House.transform.GetChild(1).GetComponent<SpriteRenderer>();
        HouseSide1 = House.transform.GetChild(2).GetComponent<SpriteRenderer>();
        HouseSide2 = House.transform.GetChild(3).GetComponent<SpriteRenderer>();
        HouseFornt1 = House.transform.GetChild(4).GetComponent<SpriteRenderer>();
        Window1 = House.transform.GetChild(5).GetComponent<SpriteRenderer>();
        Window2= House.transform.GetChild(6).GetComponent<SpriteRenderer>();
        Beam1= House.transform.GetChild(7).GetComponent<SpriteRenderer>();
        Beam2 = House.transform.GetChild(8).GetComponent<SpriteRenderer>();
        Beam3 = House.transform.GetChild(9).GetComponent<SpriteRenderer>();
        Beam4 = House.transform.GetChild(10).GetComponent<SpriteRenderer>();
        Window3 = House.transform.GetChild(11).GetComponent<SpriteRenderer>();
        HouseFornt2 = House.transform.GetChild(12).GetComponent<SpriteRenderer>();
        Beam5 = House.transform.GetChild(13).GetComponent<SpriteRenderer>();
        Beam6 = House.transform.GetChild(14).GetComponent<SpriteRenderer>();
        Beam7= House.transform.GetChild(15).GetComponent<SpriteRenderer>();
        Beam8 = House.transform.GetChild(16).GetComponent<SpriteRenderer>();
        Door1 = House.transform.GetChild(17).GetComponent<SpriteRenderer>();
        Beam9 = House.transform.GetChild(18).GetComponent<SpriteRenderer>();
        Beam10 = House.transform.GetChild(19).GetComponent<SpriteRenderer>();
        HouseFornt3 = House.transform.GetChild(20).GetComponent<SpriteRenderer>();
        Beam11 = House.transform.GetChild(21).GetComponent<SpriteRenderer>();
        Beam12 = House.transform.GetChild(22).GetComponent<SpriteRenderer>();
        Beam13 = House.transform.GetChild(23).GetComponent<SpriteRenderer>();
        Beam14 = House.transform.GetChild(24).GetComponent<SpriteRenderer>();
        RoofWood1 = House.transform.GetChild(25).GetComponent<SpriteRenderer>();
        RoofWood2 = House.transform.GetChild(26).GetComponent<SpriteRenderer>();

    }

    public void Update()
    {
        
    }

    public void DamagedHouseEffect()
    {
        Antic1.color = Antic2.color = Red;
        HouseFornt1.color = HouseFornt2.color = HouseFornt3.color = Red;
        HouseSide1.color=HouseSide2.color = Red;
        Window1.color = Window2.color = Window3.color = Red;
        Door1.color = Red;
        RoofWood1.color = RoofWood2.color = Red;
        Beam1.color = Beam2.color = Beam3.color = Beam4.color = Beam5.color = Beam6.color = Beam7.color = Beam8.color = Beam9.color = Beam10.color = Beam11.color = Beam12.color = Beam13.color = Beam14.color = Red;
        Invoke("DamagedHouseEffectOff", 0.2f);
    }
    public void DamagedHouseEffectOff()
    {
        Antic1.color = Antic2.color = White;
        HouseFornt1.color = HouseFornt2.color = HouseFornt3.color = White;
        HouseSide1.color = HouseSide2.color = White;
        Window1.color = Window2.color = Window3.color = White;
        Door1.color = White;
        RoofWood1.color = RoofWood2.color = White;
        Beam1.color = Beam2.color = Beam3.color = Beam4.color = Beam5.color = Beam6.color = Beam7.color = Beam8.color = Beam9.color = Beam10.color = Beam11.color = Beam12.color = Beam13.color = Beam14.color = White;

    }
}

