﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectEvent : MonoBehaviour
{
    public GameObject Event;




    void ActiveEvent()
    {
        Event.SetActive(true);
    }

}
