﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Ending : MonoBehaviour
{
    public Text Senetence;
    public Text ScoreSenetence;
    AudioSource sound;
    AudioSource effectsound;
    int Days,num;
    public void Start()
    {
        effectsound = GameObject.Find("ButtonSound").GetComponent<AudioSource>();
        sound  = GameObject.Find("H_Game_Over").GetComponent<AudioSource>();
        sound.volume = LoadData.backgroundsound;
        effectsound.volume = LoadData.effectsound;
        ScoreSenetence = GameObject.Find("EndingScore").GetComponent<Text>();
        Senetence = GameObject.Find("EndingText").GetComponent<Text>();
        Days = PlayerPrefs.GetInt("Day")-1;
        box player1 = new box();
        player1.initBox(1);
        switch (LoadData.EndingNumber)
        {
            case 1:
                Senetence.text = "당신은 오전계획 중에 체력이 다달아 사망하였습니다\n"
                    +"당신은" + Days + "일동안 생존하였습니다.";
                break;
            case 2:
                Senetence.text = "당신은 오전습격에 집이 무너져 사망하였습니다\n"
                   + "당신은" + Days + "일동안 생존하였습니다.";
                break;
            case 3:
                Senetence.text = "당신은 오후계획 중에 체력이 다달아 사망하였습니다\n"
                    + "당신은" + Days + "일동안 생존하였습니다.";
                break;
            case 4:
                Senetence.text = "당신은 오후습격에 집이 무너져 사망하였습니다\n"
                  + "당신은" + Days + "일동안 생존하였습니다.";
                break;
            case 5:
                Senetence.text = "당신은 야간계획 중에 체력이 다달아 사망하였습니다\n"
                    + "당신은" + Days + "일동안 생존하였습니다.";
                break;
            case 6:
                Senetence.text = "당신은 야간계획에 집이 무너져 사망하였습니다\n"
                    + "당신은" + Days + "일동안 생존하였습니다.";
                break;
            case 7:
                Senetence.text = "당신은 야간습격에 체력이 다달아 사망하였습니다\n"
                    + "당신은" + Days + "일동안 생존하였습니다.";
                break;
            case 8:
                Senetence.text = "당신은 야간습격에 집이 무너져 사망하였습니다\n"
                    + "당신은" + Days + "일동안 생존하였습니다.";
                break;
            default:
                Senetence.text = "";
                break;
        }
        num += Days * 300;
        num += 300 * (player1.ReturnFlash() + player1.ReturnSpanner() + player1.ReturnAxe() + player1.ReturnHammer() + player1.ReturnLantern() + player1.ReturnCrowbar() + player1.ReturnInventory());
        num += 20 * (player1.ReturnWood() + player1.ReturnIron());
        num +=10 * (player1.ReturnFood() + player1.ReturnWater());

        ScoreSenetence.text = "당신의 점수는" +num+"입니다";



    }
    public void RePlay()
    {
        effectsound.Play();
        SceneManager.LoadScene("StartScene");
        LoadData.checkstart = 6;
    }
    public void Quit()
    {
        Application.Quit();
        effectsound.Play();
    }
}
