﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;



public class LoadCode : MonoBehaviour
{
    int a;
    float time;
    int assultRandom;
    int count;
    int random;
    int Food;
    int Water;
    int Woodmaterial;
    int Ironmaterial;
    int Hp;
    int Sleep;
    int Thirsty;
    int Hungry;
    int HouseHp;
    int Day;
    int i;
    int r1, Had, Sad, Aad, Bagad; // 해머어드밴,스패너어드밴,도끼어드밴티지 가방 어드밴티지
    int check;
    //float num;
    public Text Senetence;
    int outtime;
    bool Craft = true;
    int CraftNumber = 0;
    int[] array = new int[5];
    MoveCount m1, m2, m3, m4;
    Status playerstatus;
    box playerbox;
    AudioSource sound;
    int c, StopPosition;
    TestRot Spin;
    
    float anotherTime;
    bool Fadeout;
    public Image Fade;
    Color FadeColor;
    public Animation RullteMove;
    public Animation ShopRullteMove;

    bool FirstAnimation, SecondAnimation, ThirdAnimation, ForthAnimation;
    public GameObject RestCharacter;
    public MoveChar RestChar;
    public MoveChar AssultCharacter;
    public MoveChar RepairCharacter;
    public MoveChar ShopCharacter;
    public MoveChar DungeonCharacter;
    public MoveChar ForestCharacter;
    public MoveChar LandCharacter;
    // Start is called before the first frame update
    void Start()
    {
        
        Fadeout = false;
        r1 = 0;
        c = 0;
        Status player = new Status(1);
        playerstatus = player;
        box player1 = new box();
        player1.initBox(1);
        playerbox = player1;
        Spin = gameObject.GetComponent<TestRot>();

        sound = GameObject.Find("Hit_Piano_2").GetComponent<AudioSource>();
        sound.volume = LoadData.backgroundsound;
        count = 0;
        check = 0;
        i = 4;
        LoadData.Make1 = 4;
        LoadData.Make2 = 4;
        LoadData.Make3 = 4;
        LoadData.Damage1 = 0;
        LoadData.Damage2 = 0;
        LoadData.UseGold1 = 0;
        LoadData.UseGold2 = 0;
        LoadData.UseGold3 = 0;
        LoadData.UseIron1 = 0;
        LoadData.UseIron2 = 0;
        LoadData.UseIron3 = 0;
        LoadData.BS = LoadData.BF = LoadData.BA = LoadData.BH = LoadData.BL = LoadData.BC = LoadData.BI = LoadData.Broken = 0;
        FirstAnimation = SecondAnimation = ThirdAnimation = ForthAnimation = true;

        FadeColor = Fade.color;
        FadeColor.a =1.0f;
        Fade.color = FadeColor;


    }

    private void Update()
    {
        time += Time.deltaTime;

        if (Fadeout == false)
        {
            FadeColor = Fade.color;
            FadeColor.a -= Time.deltaTime;
            Fade.color = FadeColor;


            if (Fade.color.a < 0)
            {
                Fadeout = true;
                time = 0;
                check = 0;
            }
        }
        if (Fadeout == true & check == 1)
        {
            FadeColor = Fade.color;
            FadeColor.a += Time.deltaTime;
            Fade.color = FadeColor;
            if (FadeColor.a >= 1)
            {
                moveScene();
            }
        }
        //Spin.Rotate(0, 0, 1);
        //Debug.Log(Spin.rotation);
        else
        {
            //if (num >= 100.0f) num = 100.0f;


            if (time >= 1 && count == 0)
            {
                InScene(1);
                time = 1;
            }
            if (time >= 2 && count == 1)
            {
                AnimationScene(1);
                time = 2;
            }
            if (time >= 9 && count == 2)
            {
                FirstPlan();
                count++;
                time = 9;
            }
            if (time >= 10 && count == 3)
            {
                if (FirstAnimation == true)
                {
                    OutScene(1);
                    time = 10;
                    FirstAnimation = false;
                    
                }
            }// 첫번째 시뮬레이션실행
            if (time >= 11 && count ==4)
            {
                InScene(2);
                time = 11;
            }
            if (time >= 12 && count == 5)
            {
                AnimationScene(2);
                time = 12;
            }
            if (time >= 19 && count == 6)
            {
                SecondPlan();
                count++;
                time = 19;
            }
            if (time >= 20 && count == 7)
            {
                if (SecondAnimation == true)
                {
                    OutScene(2);
                    time = 20;
                    SecondAnimation = false;
                    
                }
            }// 두번째 시뮬레이션실행
            if (time >= 21 && count == 8)
            {
                InScene(3);
                time = 21;
            }
            if (time >= 22 && count == 9)
            {
                AnimationScene(3);
                time = 22;
            }
            if (time >= 29 && count == 10)
            {
                ThirdPlan();
                count++;
                time = 29;
            }// 세번째 시뮬레이션실행
            if (time >= 30 && count == 11)
            {
                if (ThirdAnimation == true)
                {
                    OutScene(3);
                    time = 30;
                    ThirdAnimation = false; 

                }
            }
            if (time >= 31 && count == 12)
            {
                
                InScene(4);
                time = 31;
            }
            if (time >= 32 && count == 13)
            {
                Loaddata();
                Plancodes Plancode3 = new Plancodes((PlayerPrefs.GetInt("ActiveCode3")), 3);
                EventScenario(Plancode3);
                AnimationScene(4);
                time = 32;
            }
            if (time >= 39 && count == 14)
            {
                LastAttack();
                count++;
                time = 39;
            }// 습격
            if (time >= 40 && count == 15)
            {
                if (ForthAnimation == true)
                {
                    OutScene(4);
                    time = 40;
                    ForthAnimation = false;
                }
            }

            if (time >= 42 && count == 16)
            {
                Fadeout = true;
                check = 1;
            } //게임화면으로 이동
        }
    }

    MoveCount Scenario(Plancodes Code)
    {


        Water = Food = Woodmaterial = Ironmaterial = Day = Hungry = Thirsty = HouseHp = Sleep = Hp = 0;


        if (Code.CodeValue() == 1)
        { //탐색1
            {
                if (random <= 20)//실패
                {
                    Food = Random.Range(0, 2) + Random.Range(0, Bagad);
                    Water = Random.Range(0, 2) + Random.Range(0, Bagad);
                    Hp -= Random.Range(10, 16) + (Aad * 10);
                    Sleep -= Random.Range(10, 21);
                    Hungry -= Random.Range(10, 21);
                    Thirsty -= Random.Range(10, 21);
                    i = 0;
                }
                else if (random <= 80 && random > 20)//성공
                {
                    Food = Random.Range(1, 3) + Random.Range(0, Bagad);
                    Water = Random.Range(1, 3) + Random.Range(0, Bagad);
                    Woodmaterial = Random.Range(0, 1);
                    Hp -= Random.Range(5, 11) + (Aad * 10);
                    Sleep -= Random.Range(10, 16);
                    Hungry -= Random.Range(10, 16);
                    Thirsty -= Random.Range(10, 16);
                    i = 1;
                }
                else if (random > 80)//대성공
                {
                    Food = Random.Range(2, 4) + Aad + Random.Range(0, Bagad); ;
                    Water = Random.Range(2, 4) + Aad + Random.Range(0, Bagad); ;
                    Woodmaterial = Random.Range(1, 2);
                    Sleep -= Random.Range(10, 16);
                    Hungry -= Random.Range(10, 16);
                    Thirsty -= Random.Range(10, 16);
                    i = 2;
                }
            }
        }
        else if (Code.CodeValue() == 2)//탐색 2
        {
            if (random <= 20)//실패
            {
                Food = Random.Range(1, 3) + Random.Range(0, Bagad); ;
                Water = Random.Range(1, 3) + Random.Range(0, Bagad); ;
                Woodmaterial = Random.Range(0, 1) + Random.Range(0, Bagad); ;
                Hp -= Random.Range(15, 21) + (Aad * 10); ;
                Sleep -= Random.Range(20, 31);
                Hungry -= Random.Range(20, 31);
                Thirsty -= Random.Range(20, 31);
                i = 0;
            }
            else if (random <= 80 && random > 20)//성공
            {
                Food = Random.Range(3, 6) + Random.Range(0, Bagad); ;
                Water = Random.Range(3, 6) + Random.Range(0, Bagad); ;
                Woodmaterial = Random.Range(1, 3) + Random.Range(0, Bagad); ;
                Ironmaterial = Random.Range(0, 1) + Random.Range(0, Bagad); ;
                Hp -= Random.Range(10, 16) + (Aad * 10); ;
                Sleep -= Random.Range(15, 21);
                Hungry -= Random.Range(15, 21);
                Thirsty -= Random.Range(15, 21);
                i = 1;
            }
            else if (random > 80)//대성공
            {
                Food = Random.Range(4, 8) + Aad + Random.Range(0, Bagad); ;
                Water = Random.Range(4, 8) + Aad + Random.Range(0, Bagad); ;
                Woodmaterial = Random.Range(2, 4) + Aad + Random.Range(0, Bagad); ;
                Ironmaterial = Random.Range(1, 3) + Aad + Random.Range(0, Bagad); ;
                Sleep -= Random.Range(10, 16);
                Hungry -= Random.Range(10, 16);
                Thirsty -= Random.Range(10, 16);
                if (playerbox.ReturnInventory() < 1)
                {
                    playerbox.Inventorycal(1);
                    if (Code.TimeValue() == 1)
                        LoadData.GetI1 = 1;
                    if (Code.TimeValue() == 2)
                        LoadData.GetI2 = 1;
                    if (Code.TimeValue() == 3)
                        LoadData.GetI3 = 1;
                }
                i = 2;
            }
        }
        else if (Code.CodeValue() == 3) //탐색 3
        {
            if (random <= 20)//실패
            {

                Woodmaterial = Random.Range(2, 4) + Random.Range(0, Bagad); ;
                Ironmaterial = Random.Range(1, 2) + Random.Range(0, Bagad); ;
                Hp -= Random.Range(20, 26) + (Aad * 10); ;
                Sleep -= Random.Range(20, 31);
                Hungry -= Random.Range(20, 31);
                Thirsty -= Random.Range(20, 31);
                i = 0;
            }
            else if (random <= 80 && random > 20)//성공
            {
                Food = Random.Range(0, 1) + Random.Range(0, Bagad); ;
                Water = Random.Range(0, 1) + Random.Range(0, Bagad); ;
                Woodmaterial = Random.Range(3, 5) + Random.Range(0, Bagad); ;
                Ironmaterial = Random.Range(2, 4) + Random.Range(0, Bagad); ;
                Hp -= Random.Range(15, 21) + (Aad * 10);
                Sleep -= Random.Range(15, 21);
                Hungry -= Random.Range(15, 21);
                Thirsty -= Random.Range(15, 21);
                i = 1;
            }
            else if (random > 80)//대성공
            {
                Food = Random.Range(1, 2) + Aad + Random.Range(0, Bagad); ;
                Water = Random.Range(1, 2) + Aad + Random.Range(0, Bagad); ;
                Woodmaterial = Random.Range(4, 6) + Random.Range(0, Bagad); ;
                Ironmaterial = Random.Range(3, 5) + Random.Range(0, Bagad); ;
                Sleep -= Random.Range(10, 16);
                Hungry -= Random.Range(10, 16);
                Thirsty -= Random.Range(10, 16);
                if (playerbox.ReturnFlash() < 1)
                {
                    playerbox.Flashcal(1);
                    if (Code.TimeValue() == 1)
                        LoadData.GetF1 = 1;
                    if (Code.TimeValue() == 2)
                        LoadData.GetF2 = 1;
                    if (Code.TimeValue() == 3)
                        LoadData.GetF3 = 1;
                }
                i = 2;
            }
        }
        else if (Code.CodeValue() == 4)//수리
        {
            r1 = 0;
            if (playerbox.ReturnWood() >= 1 | playerbox.ReturnIron() >= 1)
            {
                for (int i = 0; i < 3; i++)
                {
                    if (playerbox.ReturnWood() >= 1)
                    {
                        if (2000 > playerstatus.ReturnHouseHp())
                        {
                            playerstatus.HouseHpcalculate(100 + Had + Sad);

                            playerbox.Woodcal(-1);
                            playerstatus.Sleepcalculate(Random.Range(10, 16));
                            playerstatus.Thirstycalculate(Random.Range(10, 16));
                            playerstatus.Hungrycalculate(Random.Range(10, 16));
                            r1 += 100 + Had + Sad;
                            switch (Code.TimeValue())
                            {
                                case 1: LoadData.UseGold1 += 1; break;
                                case 2: LoadData.UseGold2 += 1; break;
                                case 3: LoadData.UseGold3 += 1; break;
                            }

                        }
                    }
                }
                for (int i = 0; i < 3; i++)
                {
                    if (playerbox.ReturnIron() >= 1)
                    {
                        if (2000 > playerstatus.ReturnHouseHp())
                        {
                            playerstatus.HouseHpcalculate(300 + Had + Sad);
                            playerbox.Ironcal(-1);
                            playerstatus.Sleepcalculate(Random.Range(10, 16));
                            playerstatus.Thirstycalculate(Random.Range(10, 16));
                            playerstatus.Hungrycalculate(Random.Range(10, 16));
                            r1 += 300 + Had + Sad;
                            switch (Code.TimeValue())
                            {
                                case 1: LoadData.UseIron1 += 1; break;
                                case 2: LoadData.UseIron2 += 1; break;
                                case 3: LoadData.UseIron3 += 1; break;
                            }
                        }
                    }
                }
                i = 4;
            }
            else
            {
                Water = Food = Woodmaterial = Ironmaterial = Day = Hungry = Thirsty = HouseHp = Sleep = Hp = 0;
                Hp = 40;
                Sleep = 50;
                Hungry -= 10;
                Thirsty -= 10;
                i = 4;
            }
        }

        else if (Code.CodeValue() == 5)//제작
        {

            switch (CraftNumber)
            {
                case 1:
                    playerbox.Spannercal(1);
                    playerbox.Woodcal(-3);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseGold1 = -3; break;
                        case 2: LoadData.UseGold2 = -3; break;
                        case 3: LoadData.UseGold3 = -3; break;
                    }
                    playerstatus.Sleepcalculate(Random.Range(10, 16));
                    playerstatus.Thirstycalculate(Random.Range(10, 16));
                    playerstatus.Hungrycalculate(Random.Range(10, 16));
                    if (Code.TimeValue() == 1)
                        LoadData.Make1 = 1;
                    if (Code.TimeValue() == 2)
                        LoadData.Make2 = 1;
                    if (Code.TimeValue() == 3)
                        LoadData.Make3 = 1;
                    break;
                case 2:
                    playerbox.Axecal(1);
                    playerbox.Ironcal(-2);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseIron1 = -2; break;
                        case 2: LoadData.UseIron2 = -2; break;
                        case 3: LoadData.UseIron3 = -2; break;
                    }
                    playerbox.Woodcal(-5);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseGold1 = -5; break;
                        case 2: LoadData.UseGold2 = -5; break;
                        case 3: LoadData.UseGold3 = -5; break;
                    }
                    playerstatus.Sleepcalculate(Random.Range(10, 16));
                    playerstatus.Thirstycalculate(Random.Range(10, 16));
                    playerstatus.Hungrycalculate(Random.Range(10, 16));
                    if (Code.TimeValue() == 1)
                        LoadData.Make1 = 2;
                    if (Code.TimeValue() == 2)
                        LoadData.Make2 = 2;
                    if (Code.TimeValue() == 3)
                        LoadData.Make3 = 2;
                    break;
                case 3:
                    playerbox.Hammercal(1);
                    playerbox.Ironcal(-3);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseIron1 = -3; break;
                        case 2: LoadData.UseIron2 = -3; break;
                        case 3: LoadData.UseIron3 = -3; break;
                    }
                    LoadData.UseIron1 = -3;
                    playerbox.Woodcal(-8);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseGold1 = -8; break;
                        case 2: LoadData.UseGold2 = -8; break;
                        case 3: LoadData.UseGold3 = -8; break;
                    }
                    playerstatus.Sleepcalculate(Random.Range(10, 16));
                    playerstatus.Thirstycalculate(Random.Range(10, 16));
                    playerstatus.Hungrycalculate(Random.Range(10, 16));
                    if (Code.TimeValue() == 1)
                        LoadData.Make1 = 3;
                    if (Code.TimeValue() == 2)
                        LoadData.Make2 = 3;
                    if (Code.TimeValue() == 3)
                        LoadData.Make3 = 3;
                    break;
                case 4:
                    playerbox.Lanterncal(1);
                    playerbox.Ironcal(-4);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseIron1 = -4; break;
                        case 2: LoadData.UseIron2 = -4; break;
                        case 3: LoadData.UseIron3 = -4; break;
                    }
                    playerbox.Woodcal(-3);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseGold1 = -3; break;
                        case 2: LoadData.UseGold2 = -3; break;
                        case 3: LoadData.UseGold3 = -3; break;
                    }
                    playerstatus.Sleepcalculate(Random.Range(10, 16));
                    playerstatus.Thirstycalculate(Random.Range(10, 16));
                    playerstatus.Hungrycalculate(Random.Range(10, 16));
                    if (Code.TimeValue() == 1)
                        LoadData.Make1 = 5;
                    if (Code.TimeValue() == 2)
                        LoadData.Make2 = 5;
                    if (Code.TimeValue() == 3)
                        LoadData.Make3 = 5;
                    break;
                case 5:
                    playerbox.Crwobarcal(1);
                    playerbox.Ironcal(-7);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseIron1 = -7; break;
                        case 2: LoadData.UseIron2 = -7; break;
                        case 3: LoadData.UseIron3 = -7; break;
                    }
                    playerbox.Woodcal(-5);
                    switch (Code.TimeValue())
                    {
                        case 1: LoadData.UseGold1 = -5; break;
                        case 2: LoadData.UseGold2 = -5; break;
                        case 3: LoadData.UseGold3 = -5; break;
                    }
                    playerstatus.Sleepcalculate(Random.Range(10, 16));
                    playerstatus.Thirstycalculate(Random.Range(10, 16));
                    playerstatus.Hungrycalculate(Random.Range(10, 16));
                    if (Code.TimeValue() == 1)
                        LoadData.Make1 = 6;
                    if (Code.TimeValue() == 2)
                        LoadData.Make2 = 6;
                    if (Code.TimeValue() == 3)
                        LoadData.Make3 = 6;
                    break;
                case 9:
                    LoadData.Make3 = 4;
                    break;



            }

            i = 5;
        }
        else if (Code.CodeValue() == 6)//회복
        {
            Hp = 40;
            Sleep = 50;
            Hungry -= 10;
            Thirsty -= 10;
            i = 6;
        }
        MoveCount m1 = new MoveCount(Code.TimeValue(), Water, Food, Woodmaterial, Ironmaterial, Hungry, Thirsty, HouseHp, Hp, Sleep);
        cal();
        playerbox.Woodcal(Woodmaterial);
        playerbox.Ironcal(Ironmaterial);
        playerbox.Watercal(Water);
        playerbox.Foodcal(Food);

        return m1;
    }

    MoveCount EventScenario(Plancodes Code)
    {
        Water = Food = Woodmaterial = Ironmaterial = Hungry = Thirsty = Sleep = HouseHp = Hp = 0;
        Day = PlayerPrefs.GetInt("Day");
        if (Code.CodeValue() == 1 | Code.CodeValue() == 2 | Code.CodeValue() == 3) //야간탐색나간경우 1로
        {
            outtime = 1;
            LoadData.Event = 1;
        }
        else
        {
            outtime = 0;
            LoadData.Event = 0;
        }
        for (int i = 0; i < Day; i++)
        {
            if (Random.Range(1, 3) == 1)
                HouseHp -= Random.Range(10, 30);
            if (Random.Range(1, 9) == 1 & outtime == 0)//야간에 제작/휴식으로집에있을경우 데미지받음
                Hp -= Random.Range(1, 10);
        }
        LoadData.Damage1 -= Hp;
        LoadData.Damage2 -= HouseHp;
        if (outtime == 0)
        {
            
            switch (assultRandom)
            {
                case 1:
                    if (playerbox.ReturnSpanner() >= 1)
                    {
                        playerbox.Spannercal(-1);
                        LoadData.BS = 1;
                        LoadData.Broken = 1;
                    }
                    break;
                case 2:
                    if (playerbox.ReturnHammer() >= 1)
                    {
                        playerbox.Hammercal(-1);
                        LoadData.BH = 1;
                        LoadData.Broken = 1;
                    }
                    break;
                case 3:
                    if (playerbox.ReturnAxe() >= 1)
                    {
                        playerbox.Axecal(-1);
                        LoadData.BA = 1;
                        LoadData.Broken = 1;
                    }
                    break;
                case 4:
                    if (playerbox.ReturnLantern() >= 1)
                    {
                        playerbox.Lanterncal(-1);
                        LoadData.BL = 1;
                        LoadData.Broken = 1;
                    }
                    break;
                case 5:
                    if (playerbox.ReturnInventory() >= 1)
                    {
                        playerbox.Inventorycal(-1);
                        LoadData.BI = 1;
                        LoadData.Broken = 1;
                    }
                    break;
                case 6:
                    if (playerbox.ReturnCrowbar() >= 1)
                    {
                        playerbox.Crwobarcal(-1);
                        LoadData.BC = 1;
                        LoadData.Broken = 1;
                    }
                    break;
                case 7:
                    if (playerbox.ReturnFlash() >= 1)
                    {
                        playerbox.Flashcal(-1);
                        LoadData.BF = 1;
                        LoadData.Broken = 1;
                    }
                    break;
                default: break;
            }
        }

        MoveCount m1 = new MoveCount(0, Water, Food, Woodmaterial, Ironmaterial, Hungry, Thirsty, HouseHp, Hp, Sleep);
        cal();
        return m1;
    }

    void Rcube(GameObject R)
    {
        R.SetActive(true);
    }
    void FirstPlan()
    {
        Loaddata();//캐릭터의 스테이터스,소유아이템 받아오기
        Plancodes Plancode1 = new Plancodes((PlayerPrefs.GetInt("ActiveCode1")), 1);//오전계획과 오전번호로 번호생성

        m1 = Scenario(Plancode1);//오전계획에정해둔계획을 오전으로 처리

        //Debug.Log("오전계획값" + random);
        LoadData.Water1 = m1.Water;
        LoadData.Food1 = m1.Food;
        LoadData.Wood1 = m1.Wood;
        LoadData.Iron1 = m1.Iron;
        LoadData.hp1 = m1.Hp;
        LoadData.househp1 = m1.HouseHp;
        LoadData.hungry1 = m1.Hungry;
        LoadData.thirsty1 = m1.Thirsty;
        LoadData.sleep1 = m1.Sleep;
        LoadData.PLANcode1 = Plancode1.CodeValue();
        LoadData.Result1 = i;
        LoadData.Repair1 = r1;
        Savedata();//데이터 저장

        if (playerstatus.ending == 1 & check == 0)
        {
            LoadData.EndingNumber = 1;//아침 체력사망
            Fadeout = true;
            check = 1;
        }
        else if (playerstatus.ending == 2 & check == 0)
        {
            LoadData.EndingNumber = 2;//아침 건물사망
            Fadeout = true;
            check = 1;
        }

    }
    void SecondPlan()
    {
        Loaddata();
        Plancodes Plancode2 = new Plancodes((PlayerPrefs.GetInt("ActiveCode2")), 2);//오후계획과 오후번호로 번호생성

        m2 = Scenario(Plancode2);//오후계획에정해둔계획을 오후으로 처리
        //Debug.Log("오후계획값" + random);
        LoadData.Water2 = m2.Water;
        LoadData.Food2 = m2.Food;
        LoadData.Wood2 = m2.Wood;
        LoadData.Iron2 = m2.Iron;
        LoadData.hp2 = m2.Hp;
        LoadData.househp2 = m2.HouseHp;
        LoadData.hungry2 = m2.Hungry;
        LoadData.thirsty2 = m2.Thirsty;
        LoadData.sleep2 = m2.Sleep;
        LoadData.PLANcode2 = Plancode2.CodeValue();
        LoadData.Result2 = i;
        LoadData.Repair2 = r1;
        Savedata();
        //오후계획에 결과물들을 저장
        if (playerstatus.ending == 1 & check == 0)
        {
            LoadData.EndingNumber = 3;//주간 체력사망
            Fadeout = true;
            check = 1;
        }
        else if (playerstatus.ending == 2 & check == 0)
        {
            LoadData.EndingNumber = 4;//주간 건물사망
            Fadeout = true;
            check = 1;
        }

    }
    void ThirdPlan()
    {
        Loaddata();
        Plancodes Plancode3 = new Plancodes((PlayerPrefs.GetInt("ActiveCode3")), 3);
        m3 = Scenario(Plancode3);
        //Debug.Log("야간계획값" + random);
        LoadData.Water3 = m3.Water;
        LoadData.Food3 = m3.Food;
        LoadData.Wood3 = m3.Wood;
        LoadData.Iron3 = m3.Iron;
        LoadData.hp3 = m3.Hp;
        LoadData.househp3 = m3.HouseHp;
        LoadData.hungry3 = m3.Hungry;
        LoadData.thirsty3 = m3.Thirsty;
        LoadData.sleep3 = m3.Sleep;
        LoadData.PLANcode3 = Plancode3.CodeValue();
        LoadData.Result3 = i;
        LoadData.Repair3 = r1;
        Savedata();
        if (playerstatus.ending == 1 & check == 0)
        {
            LoadData.EndingNumber = 5;//야간 체력사망
            Fadeout = true;
            check = 1;
        }
        else if (playerstatus.ending == 2 & check == 0)
        {
            LoadData.EndingNumber = 6;//야간 건물사망
            Fadeout = true;
            check = 1;
        }

    }
    void LastAttack      ()
    {
        
        
        

        if (playerstatus.ending == 1 & check == 0)
        {
            LoadData.EndingNumber = 7;//야간습격 체력사망
            Fadeout = true;
            check = 1;
        }
        else if (playerstatus.ending == 2 & check == 0)
        {
            LoadData.EndingNumber = 8;//야간습격 건물사망
            Fadeout = true;
            check = 1;
        }
    }
    void moveScene()
    {
        Savedata();
        playerstatus.DayPlus();
        PlayerPrefs.SetInt("Day", playerstatus.ReturnDay());
        PlayerPrefs.SetInt("Intro", 2);
        if (playerstatus.ReturnDay() >= 30)
            playerstatus.ending = 100;
        if (playerstatus.ending == 0)
            SceneManager.LoadScene("GameScene");
        else if (playerstatus.ending == 100)
            SceneManager.LoadScene("LastScene");
        else
            SceneManager.LoadScene("Ending");
    }
    void cal()
    {


        playerstatus.Sleepcalculate(Sleep);
        playerstatus.Thirstycalculate(Thirsty);
        playerstatus.Hungrycalculate(Hungry);
        playerstatus.Hpcalculate(Hp);
        playerstatus.HouseHpcalculate(HouseHp);

    }

    void Savedata()
    {
        PlayerPrefs.SetInt("Wood", playerbox.ReturnWood());
        PlayerPrefs.SetInt("Iron", playerbox.ReturnIron());
        PlayerPrefs.SetInt("Water", playerbox.ReturnWater());
        PlayerPrefs.SetInt("Food", playerbox.ReturnFood());
        PlayerPrefs.SetInt("Axe", playerbox.ReturnAxe());
        PlayerPrefs.SetInt("Hammer", playerbox.ReturnHammer());
        PlayerPrefs.SetInt("Spanner", playerbox.ReturnSpanner());
        PlayerPrefs.SetInt("Flash", playerbox.ReturnFlash());
        PlayerPrefs.SetInt("Crowbar", playerbox.ReturnCrowbar());
        PlayerPrefs.SetInt("Lantern", playerbox.ReturnLantern());
        PlayerPrefs.SetInt("Inventory", playerbox.ReturnInventory());
        PlayerPrefs.SetInt("Hp", playerstatus.ReturnHp());
        PlayerPrefs.SetInt("HouseHp", playerstatus.ReturnHouseHp());
        PlayerPrefs.SetInt("Day", playerstatus.ReturnDay());
        PlayerPrefs.SetInt("Sleep", playerstatus.ReturnSleep());
        PlayerPrefs.SetInt("Hungry", playerstatus.ReturnHungry());
        PlayerPrefs.SetInt("Thirsty", playerstatus.ReturnThirsty());
    }
    void Loaddata()
    {
        Water = PlayerPrefs.GetInt("Water");
        Food = PlayerPrefs.GetInt("Food");
        Woodmaterial = PlayerPrefs.GetInt("Wood");
        Ironmaterial = PlayerPrefs.GetInt("Iron");
        Day = PlayerPrefs.GetInt("Day");
        Hungry = PlayerPrefs.GetInt("Hungry");
        Thirsty = PlayerPrefs.GetInt("Thirsty");
        HouseHp = PlayerPrefs.GetInt("HouseHp");
        Sleep = PlayerPrefs.GetInt("Sleep");
        Hp = PlayerPrefs.GetInt("Hp");
    }


    int RandomValue(int night)
    {
        random = Random.Range(1, 101);
        if (playerbox.ReturnCrowbar() >= 1)
        {
            random += 20;
        }
        if (playerbox.ReturnInventory() >= 1)
        {
            Bagad = 2;
        }
        else
        {
            Bagad = 1;
        }
        if (playerbox.ReturnHammer() >= 1)
            Had = 100;
        if (playerbox.ReturnAxe() >= 1)
        {
            Aad += 1;
            random += 10;
        }
        if (playerbox.ReturnSpanner() >= 1)
            Sad = 50;
        if (night == 3)
        {
            random -= 40;
            if (playerbox.ReturnFlash() >= 1)
                random += 20;
            if (playerbox.ReturnLantern() >= 1)
                random += 20;
        }

        if (random < 0)
        { random = 0; }
        else if (random > 100)
        {
            random = 100;
        }


        return random;
    }
    void CraftSelect()
    {

        if (playerbox.ReturnWood() >= 3 & playerbox.ReturnSpanner() < 1)
            array[0] = 1;
        else
            array[0] = 0;
        if (playerbox.ReturnWood() >= 5 & playerbox.ReturnIron() >= 2 & playerbox.ReturnAxe() < 1)
            array[1] = 1;
        else
            array[1] = 0;
        if (playerbox.ReturnIron() >= 3 & playerbox.ReturnWood() >= 8 & playerbox.ReturnHammer() < 1)
            array[2] = 1;
        else
            array[2] = 0;
        if (playerbox.ReturnIron() >= 4 & playerbox.ReturnWood() >= 3 & playerbox.ReturnLantern() < 1)
            array[3] = 1;
        else
            array[3] = 0;
        if (playerbox.ReturnIron() >= 7 & playerbox.ReturnWood() >= 5 & playerbox.ReturnCrowbar() < 1)
            array[4] = 1;
        else
            array[4] = 0;
        while (Craft)
        {
            random = Random.Range(0, 5);

            if ((array[0] + array[1] + array[2] + array[3] + array[4]) == 0)
            {
                CraftNumber = 9;
                break;
            }
            if (array[random] == 1)
            {
                CraftNumber = random + 1;
                break;

            }
        }
    }



    void CallRoullte()
    {
        Spin.ResetSpin();
        RullteMove.Play("RoullteMove1");

    }
    void CallShopRoullte()
    {
        Spin.ResetSpin();
        ShopRullteMove.Play("RoullteMove1");

    }
    void ExitRoullte()
    {
        Spin.OFFEFFECT();
        RullteMove.Play("RoullteMove2");
    }
    void ExitShopRoullte()
    {
        Spin.OFFEFFECT();
        ShopRullteMove.Play("RoullteMove2");
    }
    void InHouseAnimation()
    {
        RestCharacter.SetActive(true);
        RestChar.InRestScene();//화면등장1초소모


    }
    void RestAnimationActive()
    {
        RestChar.WalkChar();
    }
    void RestAnimationOut()
    {
        RestChar.OutRestScene();
    }
    void HideChar()
    {
        RestCharacter.SetActive(false);
    }
    public void SpinAction()
    {
        //Spin.spin(5.0f, 40 - 0, a);//5초 회전
        Spin.spin(5.0f, 40 - StopPosition,a);//5초 회전
    }

    void InScene(int num)
    {
        
        count++;
        switch (num)
        {
            case 1:
                if ((PlayerPrefs.GetInt("ActiveCode1") == 1) || (PlayerPrefs.GetInt("ActiveCode1") == 2) || (PlayerPrefs.GetInt("ActiveCode1") == 3))
                {
                    if (PlayerPrefs.GetInt("ActiveCode1") == 1)
                    {
                        LandCharacter.InDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode1") == 2)
                    {
                        ForestCharacter.InDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode1") == 3)
                    {
                        DungeonCharacter.InDungeonScene();
                    }
                    Invoke("CallRoullte", 1.0f);

                }
                if (PlayerPrefs.GetInt("ActiveCode1") == 4)
                {
                    RepairCharacter.InRestScene();
                }
                if (PlayerPrefs.GetInt("ActiveCode1") == 5)
                {
                    CraftSelect();
                    ShopCharacter.InShopScene();
                    Invoke("CallShopRoullte", 1.0f);
                }
                if ((PlayerPrefs.GetInt("ActiveCode1") == 6))
                {
                    InHouseAnimation();
                }
                break;
            case 2:
                if ((PlayerPrefs.GetInt("ActiveCode2") == 1) || (PlayerPrefs.GetInt("ActiveCode2") == 2) || (PlayerPrefs.GetInt("ActiveCode2") == 3))
                {
                    if (PlayerPrefs.GetInt("ActiveCode2") == 1)
                    {
                        LandCharacter.InDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode2") == 2)
                    {
                        ForestCharacter.InDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode2") == 3)
                    {
                        DungeonCharacter.InDungeonScene();
                    }
                    Invoke("CallRoullte", 1.0f);
                }
                if (PlayerPrefs.GetInt("ActiveCode2") == 4)
                {
                    RepairCharacter.InRestScene();
                }
                if (PlayerPrefs.GetInt("ActiveCode2") == 5)
                {
                    CraftSelect();
                    ShopCharacter.InShopScene();
                    Invoke("CallShopRoullte", 1.0f);
                }
                if ((PlayerPrefs.GetInt("ActiveCode2") == 6))
                {
                    InHouseAnimation();
                }
                break;
            case 3:
                if ((PlayerPrefs.GetInt("ActiveCode3") == 1) || (PlayerPrefs.GetInt("ActiveCode3") == 2) || (PlayerPrefs.GetInt("ActiveCode3") == 3))
                {
                    if (PlayerPrefs.GetInt("ActiveCode3") == 1)
                    {
                        LandCharacter.InDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode3") == 2)
                    {
                        ForestCharacter.InDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode3") == 3)
                    {
                        DungeonCharacter.InDungeonScene();
                    }
                    Invoke("CallRoullte", 1.0f);
                }
                if (PlayerPrefs.GetInt("ActiveCode3") == 4)
                {
                    RepairCharacter.InRestScene();
                }
                if (PlayerPrefs.GetInt("ActiveCode3") == 5)
                {
                    CraftSelect();
                    ShopCharacter.InShopScene();
                    Invoke("CallShopRoullte", 1.0f);
                }
                if ((PlayerPrefs.GetInt("ActiveCode3") == 6))
                {
                    InHouseAnimation();
                }
                break;
            case 4:
                    
                assultRandom = Random.Range(1, 22);
                AssultCharacter.InAssultScene();
                break;
            default:
                break;



        }

    }
    void OutScene(int num)
    {
        
        count++;
        switch (num)
        {
            case 1:
                if ((PlayerPrefs.GetInt("ActiveCode1") == 1) || (PlayerPrefs.GetInt("ActiveCode1") == 2) || (PlayerPrefs.GetInt("ActiveCode1") == 3))
                {
                    ExitRoullte();
                    if (PlayerPrefs.GetInt("ActiveCode1") == 1)
                    {
                        LandCharacter.OutDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode1") == 2)
                    {
                        ForestCharacter.OutDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode1") == 3)
                    {
                        DungeonCharacter.OutDungeonScene();
                    }
                    
                }
                if ((PlayerPrefs.GetInt("ActiveCode1") == 4))
                {
                    RepairCharacter.OutRepairScene();

                }
                if ((PlayerPrefs.GetInt("ActiveCode1") == 5))
                {
                    ShopCharacter.OutShopScene();
                    ExitShopRoullte();

                }
                if ((PlayerPrefs.GetInt("ActiveCode1") == 6))
                {

                    RestAnimationOut();

                }
                break;
            case 2:
                if ((PlayerPrefs.GetInt("ActiveCode2") == 1) || (PlayerPrefs.GetInt("ActiveCode2") == 2) || (PlayerPrefs.GetInt("ActiveCode2") == 3))
                {
                    
                    ExitRoullte();
                    if (PlayerPrefs.GetInt("ActiveCode2") == 1)
                    {
                        LandCharacter.OutDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode2") == 2)
                    {
                        ForestCharacter.OutDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode2") == 3)
                    {
                        DungeonCharacter.OutDungeonScene();
                    }
                }
                if ((PlayerPrefs.GetInt("ActiveCode2") == 4))
                {

                    RepairCharacter.OutRepairScene();

                }
                if ((PlayerPrefs.GetInt("ActiveCode2") == 5))
                {

                    ShopCharacter.OutShopScene();
                    ExitShopRoullte();

                }
                if ((PlayerPrefs.GetInt("ActiveCode2") == 6))
                {
                    RestAnimationOut();
                }
                break;
            case 3:
                if ((PlayerPrefs.GetInt("ActiveCode3") == 1) || (PlayerPrefs.GetInt("ActiveCode3") == 2) || (PlayerPrefs.GetInt("ActiveCode3") == 3))
                {
                    
                    ExitRoullte();
                    if (PlayerPrefs.GetInt("ActiveCode3") == 1)
                    {
                        LandCharacter.OutDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode3") == 2)
                    {
                        ForestCharacter.OutDungeonScene();
                    }
                    else if (PlayerPrefs.GetInt("ActiveCode3") == 3)
                    {
                        DungeonCharacter.OutDungeonScene();
                    }
                }
                if ((PlayerPrefs.GetInt("ActiveCode3") == 4))
                {

                    RepairCharacter.OutRepairScene();

                }
                if ((PlayerPrefs.GetInt("ActiveCode3") == 5))
                {
                    ShopCharacter.OutShopScene();
                    ExitShopRoullte();

                }
                if ((PlayerPrefs.GetInt("ActiveCode3") == 6))
                {
                    RestAnimationOut();
                }
                break;
            case 4:
                AssultCharacter.OutAssultScene();
                
                if (LoadData.Damage2 <= 50)
                {
                    AssultCharacter.WeekOut();
                }
                else if (LoadData.Damage2 <= 200)
                {
                    AssultCharacter.NormalOut();
                }
                else
                {
                    AssultCharacter.HardOut();
                }
                break;
            default:
                break;
        }

    }
    void AnimationScene(int num)
    {
     
        count++;
        switch (num)
        {
            case 1:
                if ((PlayerPrefs.GetInt("ActiveCode1") == 1) || (PlayerPrefs.GetInt("ActiveCode1") == 2) || (PlayerPrefs.GetInt("ActiveCode1") == 3))
                {
                    a = 1;
                    random =RandomValue(1);
                    //Debug.Log(random);
                    if (random <= 20)
                    { StopPosition = 0; }
                    else if (random > 80)
                    {
                        StopPosition = 1;
                    }
                    else if (random > 20 && random <= 80)
                    {
                        StopPosition = Random.Range(2, 8);
                    }
                    //Debug.Log("StopPosi" + StopPosition);
                    Invoke("SpinAction", 1.5f);
                        
                    //Spin.spin(5.0f, 40 - StopPosition);//5초 회전
                    
                    //Spin.spin2(3.5f, 32 + StopPosition);

                }
                if (PlayerPrefs.GetInt("ActiveCode1") == 4)
                {
                    RepairCharacter.RepairMove();
                    //RandomValue(1);
                }
                if (PlayerPrefs.GetInt("ActiveCode1") == 5)
                {
                    a = 2;
                    if (CraftNumber==9)
                    {
                        random = Random.Range(6, 9);
                    }
                    else
                    {
                        random = CraftNumber;
                    }

                    //Debug.Log("상점에서제작될 아이템번호" + random);
                    ShopCharacter.WalkToShop();

                    StopPosition = 8 - random;

                    
                    
                    Invoke("SpinAction", 1.5f);
                }

                if ((PlayerPrefs.GetInt("ActiveCode1") == 6))
                {
                    RestAnimationActive();
                    Invoke("HideChar", 2.5f);//2초동안 플레이어가집으로걸어감
                }
                break;
            case 2:
                if ((PlayerPrefs.GetInt("ActiveCode2") == 1) || (PlayerPrefs.GetInt("ActiveCode2") == 2) || (PlayerPrefs.GetInt("ActiveCode2") == 3))
                {
                    a = 1;
                    random = RandomValue(1);
                    //Debug.Log(random);
                    if (random <= 20)
                    { StopPosition = 0; }
                    else if (random > 80)
                    {
                        StopPosition = 1;
                    }
                    else if (random > 20 && random <= 80)
                    {
                        StopPosition = Random.Range(2, 8);
                    }
                    Invoke("SpinAction", 1.5f);
                    //Debug.Log("StopPosi" + StopPosition);
                    //Spin.spin2(3.5f, 32 + StopPosition);

                }
                if (PlayerPrefs.GetInt("ActiveCode2") == 4)
                {
                    RepairCharacter.RepairMove();
                }
                if (PlayerPrefs.GetInt("ActiveCode2") == 5)
                {
                    a = 2;
                    if (CraftNumber == 9)
                    {
                        random = Random.Range(5, 9);
                    }
                    else
                    {
                        random = CraftNumber;
                    }
                    ShopCharacter.WalkToShop();
                    StopPosition = 8 - random;
                    Invoke("SpinAction", 1.5f);

                }

                if ((PlayerPrefs.GetInt("ActiveCode2") == 6))
                {
                    RestAnimationActive();
                    Invoke("HideChar", 2.5f);//2초동안 플레이어가집으로걸어감
                }
                break;
            case 3:
                if ((PlayerPrefs.GetInt("ActiveCode3") == 1) || (PlayerPrefs.GetInt("ActiveCode3") == 2) || (PlayerPrefs.GetInt("ActiveCode3") == 3))
                {
                    a = 1;
                    random = RandomValue(3);
                    //Debug.Log(random);
                    if (random <= 20)
                    { StopPosition = 0; }
                    else if (random > 80)
                    {
                        StopPosition = 1;
                    }
                    else if (random > 20 && random <= 80)
                    {
                        StopPosition = Random.Range(2, 8);
                    }
                    //Debug.Log("StopPosi" + StopPosition);
                    Invoke("SpinAction", 1.5f);
                    //Spin.spin(5.0f, 37 - StopPosition);//5초 회전
                    //Spin.spin2(3.5f, 32 + StopPosition);

                }
                if (PlayerPrefs.GetInt("ActiveCode3") == 4)
                {
                    
                    RepairCharacter.RepairMove();
                }
                if (PlayerPrefs.GetInt("ActiveCode3") == 5)
                {
                    a = 2;
                    if (CraftNumber == 9)
                    {
                        random = Random.Range(5, 9);
                    }
                    else
                    {
                        random = CraftNumber;
                    }
                    ShopCharacter.WalkToShop();
                    StopPosition = 8 - random;

                    Invoke("SpinAction", 1.5f);
                }

                if ((PlayerPrefs.GetInt("ActiveCode3") == 6))
                {
                    RestAnimationActive();
                    Invoke("HideChar", 2.5f);//2초동안 플레이어가집으로걸어감
                }
                break;
            case 4:
                
                if(LoadData.Damage2<=50)
                {
                    AssultCharacter.WeekAttack();
                }
                else if (LoadData.Damage2<=200)
                {
                    AssultCharacter.NormalAttack();
                }
                else 
                {
                    AssultCharacter.HardAttack();
                }
                break;
            default:
                break;
        }
    }
}
