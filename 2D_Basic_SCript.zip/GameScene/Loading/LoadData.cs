﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class LoadData
{
    public static int Water1, Water2, Water3;
    public static int Food1, Food2, Food3;
    public static int Wood1, Wood2, Wood3;
    public static int Iron1, Iron2, Iron3;
    public static int PLANcode1, PLANcode2, PLANcode3;
    public static int Result1, Result2, Result3;
    public static int Repair1, Repair2, Repair3;
    public static int Damage1, Damage2;
    public static int Day;
    public static int Hungry;
    public static int Thirsty;
    public static int HouseHp;
    public static int Sleep;
    public static int Hp;
    public static int EndingNumber;
    public static int hp1, hp2, hp3;
    public static int househp1, househp2, househp3;
    public static int hungry1, hungry2, hungry3;
    public static int thirsty1, thirsty2, thirsty3;
    public static int sleep1, sleep2, sleep3;
    public static int UseGold1, UseGold2, UseGold3;
    public static int UseIron1, UseIron2, UseIron3;
    public static int GetF1,GetF2,GetF3,Make1,Make2,Make3,GetI2,GetI1,GetI3;
    public static int BS, BF, BA, BH, BL, BC, BI,Broken;
    public static int Event,EventHP, EventHouseHP;
    public static float backgroundsound;
    public static float effectsound;
    public static int checkstart;
}


