﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveChar : MonoBehaviour
{
    public Animator Ani;
    public Animator Wolf;
    public Animator Goblin;
    public Animator ogre;
    public Animator Golem;

    public Animation Char;//등장?
    public Animation Assult;
    public Animation RePair;
    public Animation Shop;
    public void WalkChar()
    {
        
        Char.Play("Rest1");//캐릭터가집으로이동
        
        Ani.SetBool("Walk", true);
        Ani.SetBool("Idle", false);//안움직일때멈추는이동
        Invoke("StandChar", 2.0f);
        
    }
    public  void StandChar()
    {

        Ani.SetBool("Walk", false);//안움직일때멈추는이동
        Ani.SetBool("Idle", true);
    }
    public void InDungeonScene()
    {
        Char.Play("DungeonMove");

    }
    public void OutDungeonScene()
    {
        Char.Play("DungeonOutMove");

    }
    public void InRestScene()
    {
        Char.Play("InRest");
        
    }
    public void OutRestScene()
    {
        Char.Play("OutRest");

    }
    public void InShopScene()
    {
        Char.Play("InShop");

    }
    public void OutShopScene()
    {
        Char.Play("OutShop");

    }
    public void OutRepairScene()
    {
        RepairWalk();
        Char.Play("RepairOut");
        Invoke("StandChar", 1.0f);

    }
    public void InAssultScene()
    {
        Char.Play("AssultMove");
    }
    public void OutAssultScene()
    {
        Char.Play("AssultOutMove");
    }

    public void WeekAttack()
    {
        Assult.Play("weekAttack");
        Goblin.SetBool("Walk", true);
        Goblin.SetBool("Idle", false);//안움직일때멈추는이동
        Invoke("StopGoblin",0.5f);
        Invoke("AttackGoblin", 1.0f);
        /*
        Invoke("StopGoblin", 1.5f);
        Invoke("AttackGoblin", 2.0f);
        Invoke("StopGoblin", 2.5f);
        Invoke("AttackGoblin", 3.0f);
        Invoke("StopGoblin", 3.5f);
        Invoke("AttackGoblin", 4.0f);
        Invoke("StopGoblin", 4.5f);
        Invoke("AttackGoblin", 5.0f);
        Invoke("StopGoblin", 5.5f);
        Invoke("AttackGoblin", 6.0f);
        */

    }
    public void NormalAttack()
    {
        Assult.Play("normalAttack");
        Wolf.SetBool("Walk", true);
        Wolf.SetBool("Idle", false);
        
        ogre.SetBool("Walk", true);
        ogre.SetBool("Idle", false);
        Invoke("StopWolfOgre", 0.5f);
        Invoke("AttackWolfOgre", 1.0f);
        /*
        Invoke("StopWolfOgre", 2.0f);
        Invoke("AttackWolfOgre", 3.5f);
        Invoke("StopWolfOgre", 4.5f);
        Invoke("AttackWolfOgre", 5.0f);
        Invoke("StopWolfOgre", 6.5f);
        Invoke("AttackWolfOgre", 7.0f);
        */

    }
    public void HardAttack()
    {
        
        Assult.Play("hardAttack");
        Golem.SetBool("Walk", true);
        Golem.SetBool("Idle", false);
        Invoke("StopGolem", 0.5f);
        Invoke("AttackGolem", 1.0f);
        /*
        Invoke("StopGolem", 1.5f);
        Invoke("AttackGolem", 2.0f);
        Invoke("StopGolem", 2.5f);
        Invoke("AttackGolem", 3.0f);
        Invoke("StopGolem", 3.5f);
        Invoke("AttackGolem", 4.0f);
        Invoke("StopGolem", 4.5f);
        Invoke("AttackGolem", 5.0f);
        Invoke("StopGolem", 5.5f);
        Invoke("AttackGolem", 6.0f);
        */
    }
    public void StopGoblin()
    {
        Goblin.SetBool("Walk", false);
        Goblin.SetBool("Attack", false);
        Goblin.SetBool("Idle", true);
    }
    public void AttackGoblin()
    {
        
        Goblin.SetBool("Attack", true);
        Goblin.SetBool("Walk", false);
        Goblin.SetBool("Idle", false);
    }

    public void StopWolfOgre()
    {
        Wolf.SetBool("Walk", false);
        Wolf.SetBool("Attack", false);
        Wolf.SetBool("Idle", true);
        
        ogre.SetBool("Walk", false);
        ogre.SetBool("Attack", false);
        ogre.SetBool("Idle", true);
        
    }
    public void AttackWolfOgre()
    {

        Wolf.SetBool("Attack", true);
        Wolf.SetBool("Walk", false);
        Wolf.SetBool("Idle", false);
        ogre.SetBool("Attack", true);
        ogre.SetBool("Walk", false);
        ogre.SetBool("Idle", false);
    }
    public void StopGolem()
    {
        Golem.SetBool("Walk", false);
        Golem.SetBool("Attack", false);
        Golem.SetBool("Idle", true);
    }
    public void AttackGolem()
    {

        Golem.SetBool("Attack", true);
        Golem.SetBool("Walk", false);
        Golem.SetBool("Idle", false);
    }
    public void WeekOut()
    {
        Assult.Play("weekOut");
        Goblin.SetBool("Attack", false);
        Goblin.SetBool("Walk", true);
        
    }
    public void NormalOut()
    {
        Assult.Play("normalOut");
        Wolf.SetBool("Attack", false);
        Wolf.SetBool("Walk", true);
        ogre.SetBool("Attack", false);
        ogre.SetBool("Walk", true);
        
    }
    public void HardOut()
    {
        Assult.Play("hardOut");
        Golem.SetBool("Attack", false);
        Golem.SetBool("Walk", true);
        
    }
    public void RepairMove()
    {
        Ani.SetBool("Idle", false);
        RePair.Play("Repair");
        Ani.SetBool("Walk", true);
        Invoke("Hammer", 1.0f);
        Invoke("RepairWalk", 3.0f);
        Invoke("Hammer", 4.0f);
    }
    public void Hammer()
    {
        Ani.SetBool("Walk", false);
        
        Ani.SetBool("Attack", true);
        
    }
    public void RepairWalk()
    {
        Ani.SetBool("Attack", false);
        
        Ani.SetBool("Walk", true);
        
    }
    public void WalkToShop()
    {
        Shop.Play("WalkShop");
        Ani.SetBool("Walk", true);
    }
    
}

