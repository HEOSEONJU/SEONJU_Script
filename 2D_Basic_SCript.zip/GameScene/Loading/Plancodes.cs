﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plancodes
{

    int code;
    int Time;

    public Plancodes(int c,int T)
    {
        code = c;
        Time = T;
    }

    public void SettingCode(int n)
    {
        code = n;
    }
    public void SettingTime(int n)
    {
        Time = n;
    }
    public int CodeValue()
    { return code; }
    public int TimeValue()
    { return Time; }
}
