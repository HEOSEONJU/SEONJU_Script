﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Victory : MonoBehaviour
{
    public Text Senetence;
    public Text ScoreSenetence;
    AudioSource sound;
    AudioSource effectsound;
    int Days,num;
    public void Start()
    {
        effectsound = GameObject.Find("ButtonSound").GetComponent<AudioSource>();
        sound  = GameObject.Find("H_Game_Over").GetComponent<AudioSource>();
        sound.volume = LoadData.backgroundsound;
        effectsound.volume = LoadData.effectsound;
        ScoreSenetence = GameObject.Find("EndingScore").GetComponent<Text>();
        Senetence = GameObject.Find("EndingText").GetComponent<Text>();
        Days = PlayerPrefs.GetInt("Day");
        box player1 = new box();
        player1.initBox(1);

      Senetence.text = "당신은 바깥의 사람들에게 구해졌습니다.\n"
                    +"당신은" + Days + "일동안 생존하였습니다.";

        num += Days * 300;
        num += 300 * (player1.ReturnFlash() + player1.ReturnSpanner() + player1.ReturnAxe() + player1.ReturnHammer() + player1.ReturnLantern() + player1.ReturnCrowbar() + player1.ReturnInventory());
        num += 20 * (player1.ReturnWood() + player1.ReturnIron());
        num += 10 * (player1.ReturnFood() + player1.ReturnWater());
        ScoreSenetence.text = "당신의 점수는" +num+"입니다";
        

    }
    public void RePlay()
    {
        effectsound.Play();
        SceneManager.LoadScene("StartScene");
        LoadData.checkstart = 6;
    }
    public void Quit()
    {
        effectsound.Play();
        Application.Quit();
    }
}
