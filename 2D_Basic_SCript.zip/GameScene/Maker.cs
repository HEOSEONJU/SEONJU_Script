﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Maker : MonoBehaviour
{
    GameMain Player;
    GameObject buttonMAP;
    public int check_buttonM;
    AudioSource effectsound;
    Animator B_BOARD,M_BOARD;
    Search search;
    private void Start()
    {
        Player = GameObject.Find("Main Camera").GetComponent<GameMain>();
        buttonMAP = GameObject.Find("M_Board");
        effectsound = GameObject.Find("ButtonSound").GetComponent<AudioSource>();
        B_BOARD = GameObject.Find("B_Board").GetComponent<Animator>();
        M_BOARD = GameObject.Find("M_Board").GetComponent<Animator>();
        search = Player.MainSearch;
        check_buttonM = 0;
    }
    public void OpenMap()

    {
        effectsound.Play();
        if (check_buttonM == 0&Player.pannel==0)
        {

                M_BOARD.SetFloat("DOWN", 1.0f);
            M_BOARD.SetFloat("UP", 0.0f);
            check_buttonM = 1;
            Player.pannel = 1;
        }
        else if (check_buttonM==0 & Player.pannel==1)
        {
            if (search.check_button >= 1)
            {

                B_BOARD.SetFloat("DOWN", 0.0f);
                B_BOARD.SetFloat("UP", 1.0f);
                search.check_button = 0;
                M_BOARD.SetFloat("DOWN", 1.0f);
                M_BOARD.SetFloat("UP", 0.0f);
                check_buttonM = 1;
                //Player.pannel = 1;
            }
        }
        else if (check_buttonM == 1& Player.pannel == 1)
        {

            M_BOARD.SetFloat("DOWN", 0.0f);
            M_BOARD.SetFloat("UP", 1.0f);
            check_buttonM = 0;
            Player.pannel = 0;
        }
    }
    public void CloseMap()
    {
        effectsound.Play();
        M_BOARD.SetFloat("DOWN", 0.0f);
        M_BOARD.SetFloat("UP", 1.0f);
        check_buttonM = 0;
        Player.pannel = 0;
    }

}
