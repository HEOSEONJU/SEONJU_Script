﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Maker_Plan : MonoBehaviour
{
    GameMain Player;
    int num;
    private void Start()
    {
        Player = GameObject.Find("Main Camera").GetComponent<GameMain>();
        num = 0;
    }

    public void check_buttonM()
    {
        Plan_code();
    }


    public void Plan_code()
    {
        if (Player.plan1 == 1)
        {
            Player.ActiveCode1 = num;
        }
        else if (Player.plan1 == 2)
        {
            Player.ActiveCode2 = num;
        }
        else if (Player.plan1 == 3)
        {
            Player.ActiveCode3 = num;
        }
    }
}
