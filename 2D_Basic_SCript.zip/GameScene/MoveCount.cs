﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCount
{
    public int Hp;
    public int HouseHp;
    public int Sleep;
    public int Hungry;
    public int Thirsty;
    public int Wood;
    public int Iron;
    public int Water;
    public int Food;
    public int Time;
    public MoveCount()
    {
        Time = 0;
        Water = 0;
        Food = 0;
        Wood = 0;
        Iron = 0;

        Hungry = 0;
        Thirsty = 0;
        HouseHp = 0;
        Sleep = 0;
        Hp = 0;
    }
    public MoveCount(int t, int w, int f, int wood, int iron, int Hun, int Th, int House, int hp, int sleep)
    {
        Time = t;
        Water = w;
        Food = f;
        Wood = wood;
        Iron = iron;

        Hungry = Hun;
        Thirsty = Th;
        HouseHp = House;
        Sleep = sleep;
        Hp = hp;
    }

    public static MoveCount operator +(MoveCount p1, MoveCount p2)
    {
        MoveCount m1 = new MoveCount();
        m1.Time = 1;
        m1.Sleep = p1.Sleep + p2.Sleep;
        m1.Hp = p1.Hp + p2.Hp;
        m1.HouseHp = p1.HouseHp + p2.HouseHp;
        m1.Hungry = p1.Hungry + p2.Hungry;
        m1.Thirsty = p1.Thirsty + p2.Thirsty;
        m1.Water = p1.Water + p2.Water;
        m1.Food = p1.Food + p2.Food;
        m1.Wood = p1.Wood + p2.Wood;
        m1.Iron = p1.Iron + p2.Iron;
        if (m1.Hp <= 0)
            m1.Time = -1;
        else if(m1.HouseHp<0)
            m1.Time = -2;

        return m1;
    }

}
