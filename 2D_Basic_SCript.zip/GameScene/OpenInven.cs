﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenInven : MonoBehaviour
{
    GameMain Manager;
    GameObject UseButton;
    int a;

    public void Start()
    {
        Manager= GameObject.Find("Main Camera").GetComponent<GameMain>();

    }

    public void WaterButton()
    {
        Manager.Introboxbutton(1);
        a = 1;

    }
    public void FoodButton()
    {
        
        Manager.Introboxbutton(2);
        a = 2;

    }
    public void WoodButton()
    {
        
        Manager.Introboxbutton2(3);

    }
    public void IronButton()
    {
        
        Manager.Introboxbutton2(4);

    }
    public void FlashButton()
    {

        Manager.Introboxbutton2(5);

    }
    public void SpannerButton()
    {

        Manager.Introboxbutton2(6);

    }
    public void AxeButton()
    {

        Manager.Introboxbutton2(7);

    }
    public void HammerButton()
    {

        Manager.Introboxbutton2(8);

    }
    public void LanternButton()
    {

        Manager.Introboxbutton2(9);

    }
    public void CrowBarButton()
    {

        Manager.Introboxbutton2(10);

    }
    public void InventoryButton()
    {

        Manager.Introboxbutton2(11);

    }
    public void Cancle()
    {
        Manager.CancleButton();
    }
    public void Use()
    {

        Manager.UseButtons(a);
    }
    

}
