﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rest : MonoBehaviour
{
    GameMain Player;


    private void Start()
    {
        Player = GameObject.Find("Main Camera").GetComponent<GameMain>();

    }

    public void check_buttonR()
    {
        Plan_code();
    }
    

    public void Plan_code()
    {
        if (Player.plan1 == 1)
        {
            Player.ActiveCode1 = 4;
        }
        else if (Player.plan1 == 2)
        {
            Player.ActiveCode2 = 4;
        }
        else if (Player.plan1 == 3)
        {
            Player.ActiveCode3 = 4;
        }
    }

}
