﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResultClose : MonoBehaviour
{
    
    ResultText R1,R2,R3,R4;
    Animation MY;
    GameMain Player;
    public void CloseALLResult()
    {
        Debug.Log(0);
        Player = GameObject.Find("Main Camera").GetComponent<GameMain>();
        Debug.Log(1);
        
        
        R1 = gameObject.transform.parent.gameObject.transform.GetChild(0).transform.GetChild(0).GetComponent<ResultText>();
        
        R2 = gameObject.transform.parent.gameObject.transform.GetChild(1).transform.GetChild(0).GetComponent<ResultText>();
        R3 = gameObject.transform.parent.gameObject.transform.GetChild(2).transform.GetChild(0).GetComponent<ResultText>();
        R4 = gameObject.transform.parent.gameObject.transform.GetChild(3).transform.GetChild(0).GetComponent<ResultText>();
        R4 = gameObject.transform.parent.gameObject.transform.GetChild(3).transform.GetChild(0).GetComponent<ResultText>();
        MY = gameObject.GetComponent<Animation>();
        MY.Play("OUTMOVE5");
        R1.OUTMOVE(1);
        R2.OUTMOVE(2);
        R3.OUTMOVE(3);
        R4.OUTMOVE(4);
        Player.PageOpen = false;




    }
    public void INMOVECloseBUtton()
    {
        MY = gameObject.GetComponent<Animation>();
        MY.Play("INMOVE5");
    }
}
