﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ResultText : MonoBehaviour
{
    Animation MOVE;
    Text Water, Food, Gold, Iron;
    Text hp, househp, hungry, thirsty, sleep;
    Text itemname;
    int num;

    
    public void ViewResult()
    {
        Water = gameObject.transform.GetChild(4).gameObject.transform.GetChild(2).gameObject.GetComponent<Text>();
        Food = gameObject.transform.GetChild(5).gameObject.transform.GetChild(2).gameObject.GetComponent<Text>();
        Gold = gameObject.transform.GetChild(6).gameObject.transform.GetChild(2).gameObject.GetComponent<Text>();
        Iron = gameObject.transform.GetChild(7).gameObject.transform.GetChild(2).gameObject.GetComponent<Text>();
        itemname = gameObject.transform.GetChild(8).gameObject.GetComponent<Text>();
        hp = gameObject.transform.GetChild(10).gameObject.transform.GetChild(0).gameObject.transform.GetChild(1).GetComponent<Text>();
        househp = gameObject.transform.GetChild(10).gameObject.transform.GetChild(1).gameObject.transform.GetChild(1).GetComponent<Text>();
        hungry = gameObject.transform.GetChild(10).gameObject.transform.GetChild(2).gameObject.transform.GetChild(1).GetComponent<Text>();
        thirsty = gameObject.transform.GetChild(10).gameObject.transform.GetChild(3).gameObject.transform.GetChild(1).GetComponent<Text>();
        sleep = gameObject.transform.GetChild(10).gameObject.transform.GetChild(4).gameObject.transform.GetChild(1).GetComponent<Text>();
        if (gameObject.tag == "Mornig")
        {
            num = 1;
            
        }
        else if (gameObject.tag == "After")
        {
            num = 2;
        }
        else if (gameObject.tag == "Night")
        {
            num = 3;
        }
        else if (gameObject.tag == "Attack")
        {
            num = 4;
        }
        switch (num)
        {
            
            case 1:
                if (LoadData.PLANcode1 <= 3)
                {
                    Water.text = LoadData.Water1 + "개";
                    Food.text = LoadData.Food1 + "개";
                    Gold.text = LoadData.Wood1 + "개";
                    Iron.text = LoadData.Iron1 + "개";
                    if (LoadData.GetF1 == 1)
                        itemname.text = "고급스태프를 획득했습니다.";
                    if (LoadData.GetI1 == 1)
                        itemname.text = "가방를 획득했습니다.";
                    hp.text = LoadData.hp1 + "";
                    househp.text = LoadData.househp1 + "";
                    hungry.text = LoadData.hungry1 + "";
                    thirsty.text = LoadData.thirsty1 + "";
                    sleep.text = LoadData.sleep1 + "";

                }
                else if (LoadData.PLANcode1 == 4)
                {
                    Water.text = LoadData.Water1 + "개";
                    Food.text = LoadData.Food1 + "개";
                    Gold.text = LoadData.UseGold1 + "개";
                    Iron.text = LoadData.UseIron1 + "개";

                    hp.text = LoadData.hp1 + "";
                    househp.text = LoadData.Repair1 + "";
                    hungry.text = LoadData.hungry1 + "";
                    thirsty.text = LoadData.thirsty1 + "";
                    sleep.text = LoadData.sleep1 + "";
                }
                else if (LoadData.PLANcode1 == 5)
                {
                    Water.text = LoadData.Water1 + "개";
                    Food.text = LoadData.Food1 + "개";
                    Gold.text = LoadData.UseGold1 + "개";
                    Iron.text = LoadData.UseIron1 + "개";
                    switch (LoadData.Make1)
                    {
                        case 1: itemname.text = "단검를 획득했습니다."; break;
                        case 2: itemname.text = "도끼를 획득했습니다."; break;
                        case 3: itemname.text = "해머를 획득했습니다."; break;
                        case 4: itemname.text = "아무것도 획득하지못했습니다.."; break;
                        case 5: itemname.text = "스태프를 획득했습니다."; break;
                        case 6: itemname.text = "대검를 획득했습니다."; break;
                        default: break;

                    }

                    hp.text = LoadData.hp1 + "";
                    househp.text = LoadData.househp1 + "";
                    hungry.text = LoadData.hungry1 + "";
                    thirsty.text = LoadData.thirsty1 + "";
                    sleep.text = LoadData.sleep1 + "";
                }
                else if (LoadData.PLANcode1 == 6)
                {
                    Water.text = LoadData.Water1 + "개";
                    Food.text = LoadData.Food1 + "개";
                    Gold.text = LoadData.UseGold1 + "개";
                    Iron.text = LoadData.UseIron1 + "개";
                    hp.text = LoadData.hp1 + "";
                    househp.text = LoadData.househp1 + "";
                    hungry.text = LoadData.hungry1 + "";
                    thirsty.text = LoadData.thirsty1 + "";
                    sleep.text = LoadData.sleep1 + "";
                }

                break;
            case 2:
                if (LoadData.PLANcode2 <= 3)
                {
                    Water.text = LoadData.Water2 + "개";
                    Food.text = LoadData.Food2 + "개";
                    Gold.text = LoadData.Wood2 + "개";
                    Iron.text = LoadData.Iron2 + "개";
                    if (LoadData.GetF2 == 1)
                        itemname.text = "고급스태프를 획득했습니다.";
                    if (LoadData.GetI2 == 1)
                        itemname.text = "가방를 획득했습니다.";
                    hp.text = LoadData.hp2 + "";
                    househp.text = LoadData.househp2 + "";
                    hungry.text = LoadData.hungry2 + "";
                    thirsty.text = LoadData.thirsty2 + "";
                    sleep.text = LoadData.sleep2 + "";

                }
                else if (LoadData.PLANcode2 == 4)
                {
                    Water.text = LoadData.Water2 + "개";
                    Food.text = LoadData.Food2 + "개";
                    Gold.text = LoadData.UseGold2 + "개";
                    Iron.text = LoadData.UseIron2 + "개";

                    hp.text = LoadData.hp2 + "";
                    househp.text = LoadData.Repair2 + "";
                    hungry.text = LoadData.hungry2 + "";
                    thirsty.text = LoadData.thirsty2 + "";
                    sleep.text = LoadData.sleep2+ "";
                }
                else if (LoadData.PLANcode2 == 5)
                {
                    Water.text = LoadData.Water2 + "개";
                    Food.text = LoadData.Food2 + "개";
                    Gold.text = LoadData.UseGold2 + "개";
                    Iron.text = LoadData.UseIron2 + "개";
                    switch (LoadData.Make2)
                    {
                        case 1: itemname.text = "단검를 획득했습니다."; break;
                        case 2: itemname.text = "도끼를 획득했습니다."; break;
                        case 3: itemname.text = "해머를 획득했습니다."; break;
                        case 4: itemname.text = "아무것도 획득하지못했습니다.."; break;
                        case 5: itemname.text = "스태프를 획득했습니다."; break;
                        case 6: itemname.text = "대검를 획득했습니다."; break;
                        default: break;

                    }

                    hp.text = LoadData.hp2 + "";
                    househp.text = LoadData.househp2 + "";
                    hungry.text = LoadData.hungry2 + "";
                    thirsty.text = LoadData.thirsty2 + "";
                    sleep.text = LoadData.sleep2 + "";
                }
                else if (LoadData.PLANcode2 == 6)
                {
                    Water.text = LoadData.Water2 + "개";
                    Food.text = LoadData.Food2 + "개";
                    Gold.text = LoadData.UseGold2 + "개";
                    Iron.text = LoadData.UseIron2 + "개";
                    hp.text = LoadData.hp2 + "";
                    househp.text = LoadData.househp2 + "";
                    hungry.text = LoadData.hungry2 + "";
                    thirsty.text = LoadData.thirsty2 + "";
                    sleep.text = LoadData.sleep2 + "";
                }
                break;
            case 3:
                if (LoadData.PLANcode3 <= 3)
                {
                    Water.text = LoadData.Water3 + "개";
                    Food.text = LoadData.Food3 + "개";
                    Gold.text = LoadData.Wood3 + "개";
                    Iron.text = LoadData.Iron3 + "개";
                    if (LoadData.GetF3 == 1)
                        itemname.text = "고급스태프를 획득했습니다.";
                    if (LoadData.GetI3 == 1)
                        itemname.text = "가방를 획득했습니다.";
                    hp.text = LoadData.hp3 + "";
                    househp.text = LoadData.househp3 + "";
                    hungry.text = LoadData.hungry3 + "";
                    thirsty.text = LoadData.thirsty3 + "";
                    sleep.text = LoadData.sleep3 + "";

                }
                else if (LoadData.PLANcode3 == 4)
                {
                    Water.text = LoadData.Water3 + "개";
                    Food.text = LoadData.Food3+ "개";
                    Gold.text = LoadData.UseGold3 + "개";
                    Iron.text = LoadData.UseIron3 + "개";

                    hp.text = LoadData.hp3 + "";
                    househp.text = LoadData.Repair3 + "";
                    hungry.text = LoadData.hungry3 + "";
                    thirsty.text = LoadData.thirsty3 + "";
                    sleep.text = LoadData.sleep3 + "";
                }
                else if (LoadData.PLANcode3 == 5)
                {
                    Water.text = LoadData.Water3 + "개";
                    Food.text = LoadData.Food3 + "개";
                    Gold.text = LoadData.UseGold3 + "개";
                    Iron.text = LoadData.UseIron3 + "개";
                    switch (LoadData.Make3)
                    {
                        case 1: itemname.text = "단검를 획득했습니다."; break;
                        case 2: itemname.text = "도끼를 획득했습니다."; break;
                        case 3: itemname.text = "해머를 획득했습니다."; break;
                        case 4: itemname.text = "아무것도 획득하지못했습니다.."; break;
                        case 5: itemname.text = "스태프를 획득했습니다."; break;
                        case 6: itemname.text = "대검를 획득했습니다."; break;
                        default: break;

                    }

                    hp.text = LoadData.hp3 + "";
                    househp.text = LoadData.househp3 + "";
                    hungry.text = LoadData.hungry3 + "";
                    thirsty.text = LoadData.thirsty3 + "";
                    sleep.text = LoadData.sleep3 + "";
                }
                else if (LoadData.PLANcode3 == 6)
                {
                    Water.text = LoadData.Water3 + "개";
                    Food.text = LoadData.Food3 + "개";
                    Gold.text = LoadData.UseGold3 + "개";
                    Iron.text = LoadData.UseIron3 + "개";
                    hp.text = LoadData.hp3 + "";
                    househp.text = LoadData.househp3 + "";
                    hungry.text = LoadData.hungry3 + "";
                    thirsty.text = LoadData.thirsty3 + "";
                    sleep.text = LoadData.sleep3 + "";
                }
                break;
            case 4:
                Water.text = 0 + "개";
                Food.text = 0 + "개";
                Gold.text = 0 + "개";
                Iron.text = 0 + "개";
                hp.text = LoadData.Damage1 * -1 + "";
                househp.text = LoadData.Damage2*-1 + "";
                hungry.text = 0 + "";
                thirsty.text = 0 + "";
                sleep.text = 0 + "";
                if(LoadData.Broken>=1)
                {
                    if(LoadData.BS>=1)
                    {
                        itemname.text = "당신의 단검이 망가졌습니다.";
                    }
                    if (LoadData.BF >= 1)
                    {
                        itemname.text = "당신의 고급스태프가 망가졌습니다.";
                    }
                    if (LoadData.BA >= 1)
                    {
                        itemname.text = "당신의 도끼가 망가졌습니다.";
                    }
                    if (LoadData.BH >= 1)
                    {
                        itemname.text = "당신의 해머가 망가졌습니다.";
                    }
                    if (LoadData.BL >= 1)
                    {
                        itemname.text = "당신의 스태프가 망가졌습니다.";
                    }
                    if (LoadData.BC >= 1)
                    {
                        itemname.text = "당신의 대검이 망가졌습니다.";
                    }
                    if (LoadData.BI >= 1)
                    {
                        itemname.text = "당신의 가방이 망가졌습니다.";
                    }
                    
                }

                break;
            default:
                Debug.Log(4);
                break;
            
        }
        INMOVE(num);
    }


    public void INMOVE(int num)
    {
        MOVE = gameObject.transform.GetComponentInParent<Animation>();
        switch(num)
        {
            case 1:
                MOVE.Play("INMOVE1");
                break;
            case 2:
                MOVE.Play("INMOVE2");
                break;
            case 3:
                MOVE.Play("INMOVE3");
                break;
            case 4:
                MOVE.Play("INMOVE4");
                break;

        }
        
    }
    public void OUTMOVE(int num)
    {
        MOVE = gameObject.transform.GetComponentInParent<Animation>();
        switch (num)
        {
            case 1:
                MOVE.Play("OUTMOVE1");
                break;
            case 2:
                MOVE.Play("OUTMOVE2");
                break;
            case 3:
                MOVE.Play("OUTMOVE3");
                break;
            case 4:
                MOVE.Play("OUTMOVE4");
                break;

        }
    }
}
