﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Search : MonoBehaviour
{
    GameMain Player;
    GameObject buttonT, buttonM, buttonB,buttonMAP;
    public int check_button;
    AudioSource effectsound;
    Animator B_BOARD,M_BOARD;
    Maker maker;
    private void Start()
    {
        Player = GameObject.Find("Main Camera").GetComponent<GameMain>();
        effectsound = GameObject.Find("ButtonSound").GetComponent<AudioSource>();
        buttonMAP = GameObject.Find("B_Board");
        B_BOARD = GameObject.Find("B_Board").GetComponent<Animator>();
        maker = Player.MainMaker;
        M_BOARD = GameObject.Find("M_Board").GetComponent<Animator>();
        //buttonMAP.SetActive(false);
        check_button = 0;
    }
    public void OpenMap()

    {
        effectsound.Play();
        if (check_button == 0&Player.pannel==0)
        {

            B_BOARD.SetFloat("DOWN", 1.0f);
            B_BOARD.SetFloat("UP", 0.0f);
            check_button =1;
            Player.pannel = 1;
        }
        else if (check_button == 0 & Player.pannel == 1)
        {
            if (maker.check_buttonM >= 1)
            {

                M_BOARD.SetFloat("DOWN", 0.0f);
                M_BOARD.SetFloat("UP", 1.0f);
                maker.check_buttonM = 0;
                B_BOARD.SetFloat("DOWN", 1.0f);
                B_BOARD.SetFloat("UP", 0.0f);
                check_button = 1;
                //Player.pannel = 1;
            }
        }
        else if (check_button == 1& Player.pannel == 1)
        {

            B_BOARD.SetFloat("DOWN", 0.0f);
            B_BOARD.SetFloat("UP", 1.0f);
            check_button = 0;
            Player.pannel = 0;
        }
    }
    public void closeMap()
    {
        effectsound.Play();
        check_button = 0;
        Player.pannel = 0;
        B_BOARD.SetFloat("DOWN", 0.0f);
        B_BOARD.SetFloat("UP", 1.0f);

    }

}
