﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Search_Plan : MonoBehaviour
{
    GameMain Player;
    AudioSource effectsound;
    public int num;
    public void Start()
    {
        Player = GameObject.Find("Main Camera").GetComponent<GameMain>();
        effectsound = GameObject.Find("ButtonSound").GetComponent<AudioSource>();
    }

    private void Setting()
    {
        effectsound.Play();
        Plan_code();
    }
    public void check_buttonT()
    {
        
        Search search = GameObject.Find("morning").GetComponent<Search>();
     
        num = 1;
        Setting();
        
        search.closeMap();
    }
    public void check_buttonM()
    {
        
        Search search = GameObject.Find("morning").GetComponent<Search>();
        num = 2;
        Setting();
        search.closeMap();
    }
    public void check_buttonB()
    {
        
        Search search = GameObject.Find("morning").GetComponent<Search>();
        num = 3;
        Setting();
        search.closeMap();
    }

    public void check_buttonFix()
    {
        
        Maker maker = GameObject.Find("Button_M_M").GetComponent<Maker>();
        num = 4;
        Setting();
        maker.CloseMap();
    }
    public void check_buttonTool()
    {
        
        Maker maker = GameObject.Find("Button_M_M").GetComponent<Maker>();
        num = 5;
        Setting();
        maker.CloseMap();
    }

    public void check_buttonRest()
    {
        
        num = 6;
        Setting();
    }
    public void Plan_code()
    {
        if(Player.plantype==1)
        {
            Player.ActiveCode1 = num;
            Player.CheckMarker1();
        }
        else if (Player.plantype == 2)
        {
            Player.ActiveCode2 = num;
            Player.CheckMarker2();
        }
        else if (Player.plantype == 3)
        {
            Player.ActiveCode3 = num;
            Player.CheckMarker3();
        }
    }

}
