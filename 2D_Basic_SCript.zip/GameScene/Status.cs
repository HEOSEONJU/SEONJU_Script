﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Status 
{
    public int Day;
    public int Hp,MAXHp;
    public int HouseHp,MAXHouseHp;
    int Sleep,MAXSleep;
    int Thirsty, MAXThirsty;
    int Hungry, MAXHungry;
    public int ending;
    public Status()
    {
       Day=1;
        Hp =100;
        MAXHp =100;
       HouseHp = MAXHouseHp = 2000;
        Sleep = MAXSleep=100;
        Thirsty = 100;
            MAXThirsty=100;
       Hungry= MAXHungry=100;
        ending = 0;
    }
    public Status(int a)
    {
        Day = PlayerPrefs.GetInt("Day"); 
        Hp = PlayerPrefs.GetInt("Hp");
        MAXHp = 100;
        HouseHp = PlayerPrefs.GetInt("HouseHp");
        MAXHouseHp = 2000;
        Sleep = PlayerPrefs.GetInt("Sleep");
        MAXSleep = 100;
        Thirsty = PlayerPrefs.GetInt("Thirsty");
        MAXThirsty = 100;
        Hungry = PlayerPrefs.GetInt("Hungry");
        MAXHungry = 100;
        ending = 0;
    }
    public void SaveStatus()
    {
        PlayerPrefs.SetInt("Hp", Hp);
        PlayerPrefs.SetInt("HouseHp", HouseHp);
        PlayerPrefs.SetInt("Sleep", Sleep);
        PlayerPrefs.SetInt("Thirsty", Thirsty);
        PlayerPrefs.SetInt("Hungry", Hungry);
        PlayerPrefs.SetInt("Day", Day);
    }
    void Gameover (int a)
    {
        if(a==1)
        {
            ending = 1;
        }
            else
        {
            ending = 2;
        }
    }
    public int ReturnHp()
    {
        return Hp;
    }
    public int ReturnHouseHp()
    {
        return HouseHp;
    }
    public int ReturnSleep()
    {
        return Sleep;
    }
    public int ReturnThirsty()
    {
        return Thirsty;
    }
    public int ReturnHungry()
    {
        return Hungry;
    }
    public int ReturnMAXHp()
    {
        return MAXHp;
    }
    public int ReturnHouseMAXHp()
    {
        return MAXHouseHp;
    }
    public int ReturnMAXSleep()
    {
        return MAXSleep;
    }
    public int ReturnMAXThirsty()
    {
        return MAXThirsty;
    }
    public int ReturnMAXHungry()
    {
        return MAXHungry;
    }
    public int ReturnDay()
    {

        return Day;
    }


    public void DayPlus()
    {
        Day += 1;
    }
    
    public void Hpcalculate(int a)
    {
        Hp += a;
        if (Hp > MAXHp)
        {
            Hp = MAXHp;
        }
        if(Hp<=0)
        {
            Gameover(1);
        }
    }
    public void HouseHpcalculate(int a)
    {
        HouseHp += a;
        if (HouseHp > MAXHouseHp)
        {
            HouseHp = MAXHouseHp;
        }
        if (HouseHp <= 0)
        {
            Gameover(2);
        }
    }
    public void Sleepcalculate(int a)
    {
        Sleep += a;
        if (Sleep > MAXSleep)
        {
            Sleep = MAXSleep;
        }
        if(Sleep<0)
        {
            Hpcalculate(Sleep);
            Sleep = 0;
        }
    }
    public void Thirstycalculate(int a)
    {
        Thirsty += a;
        if (Thirsty > MAXThirsty)
        {
            Thirsty = MAXThirsty;
        }
        if (Thirsty < 0)
        {
            Hpcalculate(Thirsty);
            Thirsty = 0;
        }
    }
    public void Hungrycalculate(int a)
    {
        Hungry += a;
        if(Hungry > MAXHungry)
        {
            Hungry = MAXHungry;
        }
        if (Hungry < 0)
        {
            Hpcalculate(Hungry);
            Hungry = 0;
        }
    }
 


}
