﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TabMove : MonoBehaviour
{
    public bool BookOpenClose;
    GameObject BOOK,Inven,Char;
    GameMain Manager;
    Search search;
    Maker maker;
    //GameObject Text1;
    //GameObject BOOKBUTTON;
    void Start()
    {
        
        BookOpenClose = false;
        BOOK = GameObject.Find("책");
        Inven = GameObject.Find("InvenButton");
        Manager = GameObject.Find("Main Camera").GetComponent<GameMain>();
        GameObject mor;
        mor = Manager.Up;
        Char = GameObject.Find("Player");
        search = mor.GetComponent<Search>();
        mor = Manager.DBUTTON; 
        maker = mor.GetComponent<Maker>();



    }

    // Update is called once per frame
    void Update()
    {
        if (Manager.Fadeout == false & Manager.PageOpen == false)
        {
            if (Input.GetKeyDown(KeyCode.Tab) && (BookOpenClose == false) && (Manager.open == false))
            {
                Manager.OpenBOOK();


                BookOpenClose = true;
                Inven.SetActive(false);
                Char.SetActive(false);

            }
            else if (Input.GetKeyDown(KeyCode.Tab) && (BookOpenClose == true) && (Manager.open == true))
            {
                Manager.CloseBOOK();
                if (search.check_button >= 1)
                {
                    search.closeMap();
                }
                if (maker.check_buttonM >= 1)
                {
                    maker.CloseMap();
                }

                BookOpenClose = false;
                Inven.SetActive(true);
                Char.SetActive(true);



            }
        }
    }
}
