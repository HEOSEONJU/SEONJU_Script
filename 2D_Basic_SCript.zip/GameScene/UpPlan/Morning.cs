﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Morning : MonoBehaviour
{
    public int On;
    private void Start()
    {
    On = 0;
}
    
}
