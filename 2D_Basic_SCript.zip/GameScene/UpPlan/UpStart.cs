﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpStart : MonoBehaviour
{

    public GameObject Plan;


    // Start is called before the first frame update
    public void ActiveButton()
    {
        Plan.SetActive(true);
    }
}
