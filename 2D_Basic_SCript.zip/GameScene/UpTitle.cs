﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpTitle : MonoBehaviour
{
    GameMain Player;
    

    public void Start()
    {
        Player = GameObject.Find("Main Camera").GetComponent<GameMain>();



    }
    public void Check()
    {
        Player.plan1 = 1;
        Player.plan2 = 0;
        Player.plan3 = 0;
        
        Player.Senetence.text = "계획을 모두 정하셨습으면 완료를 누르세요 ";
        Player.Checking();
       
        
    }
}