﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialItem : Item
{
    bool Equip;
    bool Communication;
    bool batteryhave;
    bool TimeCheck;
    bool Flash;
    void Start()
    {
        if(ItemName=="Radio")
        {

            
        }
        else if (ItemName == "binoculars")
        {
               
        }
        else if (ItemName == "Watch")
        {

        }
        else if (ItemName == "FlashLight")
        {

        }

    }
}
