﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToolItem : Item
{
    bool Equip;
    bool NailUse;
    bool BoardUse;
    bool Release;
    bool Pix;
    void Start()
    {
        if(ItemName=="Spanner")
        {
            Equip=true;
            NailUse=false;
            BoardUse=false;
            Release=true;
            Pix=true;
            
        }
        else if (ItemName == "Driver")
        {
            Equip = true;
            NailUse = true;
            BoardUse = false;
            Release = false;
            Pix = false;
        }
        else if (ItemName == "Axe")
        {
            Equip = true;
            NailUse = false;
            BoardUse = true;
            Release = false;
            Pix = true;
        }
        else if (ItemName == "Hammer")
        {
            Equip = true;
            NailUse = true;
            BoardUse = false;
            Release = true;
            Pix = true;
        }
        Debug.Log(Equip);
        Debug.Log(NailUse);
        Debug.Log(BoardUse);
        Debug.Log(Release);
        Debug.Log(Pix);
    }
}
