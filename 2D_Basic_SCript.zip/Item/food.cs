﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class food : Item
{
    void Start()
    {
        ItemName = "Food";
        ItemType = 1;
        count = 0;
    }
    public void add(int n)
    {
        count += n;
    }
    public void sub(int n)
    {
        count -= n;
    }
}
