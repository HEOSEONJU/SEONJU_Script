﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class material : Item
{
    void Start()
    {
        ItemName = "material";
        ItemType = 3;
        count = 0;
    }
    public void add(int n)
    {
        count += n;
    }
    public void sub(int n)
    {
        count -= n;
    }
}
