﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class water : Item
{

    void Start()
    {
        ItemName = "Water";
        ItemType = 2;
        count = 0;
    }
    public void add(int n)
    {
        count += n;
    }
    public void sub(int n)
    {
        count -= n;
    }

}
