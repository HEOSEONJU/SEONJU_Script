﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement; //씬전환시 사용해야함
public class GameStart : MonoBehaviour
{
    AudioSource sound;
    AudioSource effectsound;
    GameObject startbutton;
    GameObject exitbutton;
    GameObject setbutton;
    GameObject settingmenu;
    Slider BackSound;
    Slider EffectSound;
    Text backnum;
    Text effnum;
    public void Start()
    {
   
        effectsound = GameObject.Find("ButtonSound").GetComponent<AudioSource>();
        sound = GameObject.Find("SR_Piano_room").GetComponent<AudioSource>();
        effectsound.volume = LoadData.effectsound;
        sound.volume = LoadData.backgroundsound;
        BackSound = GameObject.Find("BackSlider").GetComponent<Slider>();
        EffectSound = GameObject.Find("EffectSlider").GetComponent<Slider>();
        backnum = GameObject.Find("BG").GetComponent<Text>();
        effnum = GameObject.Find("Ef").GetComponent<Text>();
        startbutton = GameObject.Find("Button");
        exitbutton = GameObject.Find("Button (1)");
        setbutton = GameObject.Find("Button (2)");
        settingmenu = GameObject.Find("SETBox");
        if (LoadData.checkstart == 6)
        {

            BackSound.value = LoadData.backgroundsound;
            EffectSound.value = LoadData.effectsound;

        }
        settingmenu.SetActive(false);
        LoadData.BC = 0;
        LoadData.BL = 0;
        LoadData.BH = 0;
        LoadData.BA = 0;
        LoadData.BF = 0;
        LoadData.BS = 0;
        LoadData.BI = 0;
    }
    public void Update()
    {
        LoadData.backgroundsound=BackSound.value;
        LoadData.effectsound = EffectSound.value;
        backnum.text = ""+(int)(LoadData.backgroundsound*100);
        effnum.text = "" + (int)(LoadData.effectsound*100);
        sound.volume = LoadData.backgroundsound;
        effectsound.volume = LoadData.effectsound;
    }
    public void setting_sound()
    {
        effectsound.Play();
        startbutton.SetActive(false);
        exitbutton.SetActive(false);
        setbutton.SetActive(false);
        settingmenu.SetActive(true);
    }
    public void setting_exit()
    {
        effectsound.Play();
        startbutton.SetActive(true);
        exitbutton.SetActive(true);
        setbutton.SetActive(true);
        settingmenu.SetActive(false);
    }


    public void GameMenuMove()
    {
        effectsound.Play();
        PlayerPrefs.SetInt("Intro", 0);
        SceneManager.LoadScene("GameScene");
    }
    public void ExitGame()
    {
        effectsound.Play();
        Application.Quit();
    }


}
