using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class CharManager : MonoBehaviour
{
    Manager DataManager;
    public GameObject MonsterCard;
    public GameCard SelectedCard;
    public GameObject Infomation;
    public List<GameCard> CombatChar;
    public List<TextMeshProUGUI> TextList;
    [SerializeField]
    Transform Contents_Parent;


    //bool CanAttack;

    private void Awake()
    {
        DataManager = GetComponent<Manager>();

        //CanAttack = true;

        CombatChar = new List<GameCard>();
        for (int i = 0; i < DataManager.MYDeck.Data.UseMonsterCards.Count; i++)
        {
            int temp = DataManager.MYDeck.Data.UseMonsterCards[i];
            CombatChar.Add(MonsterCard.transform.GetChild(i).GetComponent<GameCard>());
        }
    }
    private void OnEnable()
    {
        Infomation.SetActive(false);
        //MonsterCardReset();
    }


    public void CharInit()
    {
        for (int i = 0; i < DataManager.MYDeck.Data.UseMonsterCards.Count; i++)
        {
            
            MonsterCard.transform.GetChild(i).GetComponent<GameCard>().InputID(DataManager.MYDeck.Data.UseMonsterCards[i], DataManager.MYDeck.Data);
            
        }
    }
    
    public IEnumerator MonsterCardReset(float DelayTime=3.0f)
    {
        yield return new WaitForSeconds(DelayTime);
        for (int i = 0; i < DataManager.MYDeck.Data.UseMonsterCards.Count; i++)
        {

            int temp = DataManager.MYDeck.Data.UseMonsterCards[i];
            GameCard MC = MonsterCard.transform.GetChild(i).GetComponent<GameCard>();
            for(int j=0;j<MC.Skill_ID.Count;j++)
            {
                
                if (MC.SkillDataBase.Skill[MC.Skill_ID[j]].id==0)//0���� ���½�ų
                {
                    continue;
                }
                
                //Debug.Log((i+1) + "����ĳ���� " + (j+1) + "��°��ų" +MC.Skill_ID[j]+"<���̵� /"+ MC.SkillDataBase.Skill[MC.Skill_ID[j]].CardType+"����ȣ");
                if (MC.SkillDataBase.Skill[MC.Skill_ID[j]].CardType == 0)
                {

                    
                    bool c = false;//�̹�������ִ��� �Ǵ��ϴº���
                    for (int k = 0; k < DataManager.Enemy_Manager.Card_Effect_Parent.childCount; k++)
                    {
                        SpellEffect Temp_Effect = DataManager.Enemy_Manager.Card_Effect_Parent.GetChild(k).GetComponent<SpellEffect>();
                        //Debug.Log(Temp_Effect.Type_ID[0] + "��ų���� ���̵�����");
                        //Debug.Log(Temp_Effect.Type_ID[1] + "�̹�������ִ�ID /" + MC.SkillDataBase.Skill[MC.Skill_ID[j]].id + "����ɾ��̵�");
                        if (Temp_Effect.Type_ID[0] == 0 & Temp_Effect.Type_ID[1] == MC.SkillDataBase.Skill[MC.Skill_ID[j]].id)
                        {  
                            c = true;   
                            break;
                        }
                        
                    }
                    if (c == false)
                    {
                        DataManager.Enemy_Manager.UsingSkill(MC.SkillDataBase.Skill[MC.Skill_ID[j]]);//������
                    }
                }
                else if (MC.SkillDataBase.Skill[MC.Skill_ID[j]].CardType == 1)
                {
                    GameCard temp_multi = MonsterCard.transform.GetChild(i).GetComponent<GameCard>();
                    SpellEffect Temp_Effect;
                    bool c = false;
                    for (int l = 0; l < temp_multi.EffectPosi.childCount; l++)
                    {
                        Temp_Effect = temp_multi.EffectPosi.GetChild(l).GetComponent<SpellEffect>();
                        if (Temp_Effect.Type_ID[0] == 0 & Temp_Effect.Type_ID[1] == MC.SkillDataBase.Skill[MC.Skill_ID[j]].id)
                        {

                            c = true;
                            //Debug.Log("�̹������ȿ��");
                            break;

                        }
                    }
                    if (c == false)
                    {

                        temp_multi.SkillApply(MC.SkillDataBase.Skill[MC.Skill_ID[j]], MC.Skill_ID[j]);
                    }
                }
                else if (MC.SkillDataBase.Skill[MC.Skill_ID[j]].CardType == 2)
                {
                    for(int k=0;k<DataManager.MYDeck.Data.UseMonsterCards.Count;k++)
                    {
                        GameCard temp_multi = MonsterCard.transform.GetChild(k).GetComponent<GameCard>();
                        SpellEffect Temp_Effect;
                        bool c = false;
                        for (int l = 0; l < temp_multi.EffectPosi.childCount; l++)
                        {
                            Temp_Effect = temp_multi.EffectPosi.GetChild(l).GetComponent<SpellEffect>();
                            if (Temp_Effect.Type_ID[0] == 0 & Temp_Effect.Type_ID[1] == MC.SkillDataBase.Skill[MC.Skill_ID[j]].id)
                            {

                                c = true;
                                //Debug.Log("�̹������ȿ��");
                                break;

                            }
                        }
                        if (c == false)
                        {
                            
                            temp_multi.SkillApply(MC.SkillDataBase.Skill[MC.Skill_ID[j]], MC.Skill_ID[j]);
                        }
                    }
                }
                else if (MC.SkillDataBase.Skill[MC.Skill_ID[j]].CardType == 3)
                {
                    
                    SpellCard e = new SpellCard();
                    e.Skill_Apply(MC.SkillDataBase.Skill[MC.Skill_ID[j]]);
                    DataManager.Use_MY_Effect(e,true);
                    if(e.Value_Create_Deck>0)
                    {
                        DataManager.LoadingTimer += 0.2f * e.Value_Create_Deck;
                        yield return new WaitForSeconds(0.2f*e.Value_Create_Deck);
                    }
                }

            }
            DataManager.LoadingTimer += 0.5f ;
            yield return new WaitForSeconds(0.2f);
        }

        DataManager.LoadingTimer = 0;
        DataManager.Enemy_Manager.Image_buff();
    }

    public void TurnEnd()
    {
        for (int i = 0; i < DataManager.MYDeck.Data.UseMonsterCards.Count; i++)
        {


            MonsterCard.transform.GetChild(i).GetComponent<GameCard>().TURNUSE();
        }


    }

    public int MAX_Drew_Count()
    {
        int Count = 1;
        for (int i = 0; i < DataManager.MYDeck.Data.UseMonsterCards.Count; i++)
        {


            if (Count < MonsterCard.transform.GetChild(i).GetComponent<GameCard>().MAX_DREW_Count())
                Count = MonsterCard.transform.GetChild(i).GetComponent<GameCard>().MAX_DREW_Count();
        }


        return Count;
    }

    public void Renge_HP_Effect()
    {
        for (int i = 0; i < DataManager.MYDeck.Data.UseMonsterCards.Count; i++)
        {


            MonsterCard.transform.GetChild(i).GetComponent<GameCard>().REGEN_Active();
        }

    }


    void InformationCard(bool INFO, GameCard Card)
    {

        if (INFO & Card != null)
        {
            //Debug.Log("���õȾ��̵�:" + Card.ID);
            Infomation.SetActive(true);
            Card.CalculatorStatus();

            TextList[0].text = "ATK:" + Card.Current_ATK;
            TextList[1].text = "DEF:" + Card.Current_DEF;
            TextList[2].text = "HP:" + Card.Current_HP;
            TextList[3].text = "MR:" + Card.Effect_Magic_Regi + "%";
            TextList[4].text = "CP:" + Card.Current_CriticalPercent + "%";
            TextList[5].text = "CD:" + (100 + Card.Current_CriticalDamage) + "%";

            Color color_0 = Color.white;
            color_0.a = 0;
            Color color_1 = Color.white;
            color_1.a = 1;
            for (int i = 0; i < Contents_Parent.childCount; i++)
            {
                if (Card.EffectPosi.childCount > i)
                {
                    if (Card.EffectPosi.GetChild(i).TryGetComponent<SpellEffect>(out SpellEffect Temp_effect))
                    {
                        Image temp = Contents_Parent.GetChild(i).GetComponent<Image>();
                        temp.color = color_1;
                        if (Temp_effect.Type_ID[0] == 0)//��ų������
                        {
                            temp.sprite = GameObject.Find("CardData").GetComponent<CardData>().CharSkillFile.Skill[Temp_effect.Type_ID[1]].Image;
                        }
                        else if (Temp_effect.Type_ID[0] == 1)//���������
                        {
                            temp.sprite = GameObject.Find("CardData").GetComponent<CardData>().CardDataFile.cards[Temp_effect.Type_ID[1]].Image;
                        }
                    }
                    else
                    {
                        Contents_Parent.GetChild(i).GetComponent<Image>().color = color_0;
                    }
                }
                else
                {
                    Contents_Parent.GetChild(i).GetComponent<Image>().color = color_0;
                }
            }





        }
        else
        {
            Infomation.SetActive(false);
        }
    }











    public void CardMouseOver(GameCard Card)//ī��Ȯ��
    {
        if (SelectedCard == null & !DataManager.STOP)
        {
            SelectedCard = Card;
            InformationCard(true, Card);
        }
    }
    public void CardMouseExit(GameCard Card)
    {
        InformationCard(false, Card);
        SelectedCard = null;
    }

    public void CardMouseDown()
    {

    }

    public void CardMouseUp()
    {


    }


}

