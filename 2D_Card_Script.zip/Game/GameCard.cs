using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;






public class GameCard : MonoBehaviour
{
    [Header("��������")]
    public CharCardScriptTable CardDataBase;
    public Char_Skill_ScriptTable SkillDataBase;
    public CharManager Char_manager;

    public EnemyManager Enemy_Manager;

    [Header("ī������")]
    public int ID;

    public bool Live;


    public Image BG;
    public Image MainImage;


    public string Name;
    public int Level;
    public int Atk;
    public int UPAtk;
    public int Def;
    public int UPDef;
    public int Hp;
    public int UPHp;


    public List<int> Skill_ID;
    
    public int Type;

    public int AttackType;
    public List<int> AttackEffect;
    public int AttackCount = 1;


    public int Current_ATK;
    public int Current_DEF;
    public int Current_HP;
    public int Current_MAXHP;

    public int Effect_Magic_Regi;

    public int Percent_ATK;
    public int Percent_DEF;
    public int Percent_MAXHP;

    public int Effect_ATK;
    public int Effect_DEF;
    public int Effect_HP;
    public int Effect_CP;
    public int Effect_CD;



    public SpellEffect Temp;
    public Transform EffectPosi;


    int Based_CriticalDamage;
    int Based_CriticalPercent;

    public int Current_CriticalDamage;
    public int Current_CriticalPercent;


    public Animator animator;
    public List<Animator> Text_animator;

    public List<TextMeshProUGUI> text_mesh;
    int num;

    Vector3 OriginiPosi;

    [SerializeField]
    List<Material> Shine;


    [SerializeField]
    Transform Buff_Effect_Parnet;
    [SerializeField]
    List<Transform> Buff_Effect;


    [SerializeField]
    Transform Hit_MY_Spell_Parent;
    [SerializeField]
    List<Transform> Hit_MY_Spell;
    [SerializeField]
    Image HP_BAR;

    enum Text_Array { Damaged_T, HEAL_T, ATK_T, DEF_T, ATK_Count_T, DamaedSpell_T, CP_T, CD_T };



    private void Awake()
    {




        animator = GetComponent<Animator>();
        OriginiPosi = transform.position;
        Buff_Effect = new List<Transform>();
        Hit_MY_Spell = new List<Transform>();

        for (int i= 0; i < Buff_Effect_Parnet.childCount; i++)
        {
            Buff_Effect.Add(Buff_Effect_Parnet.GetChild(i).transform);
        }
        for (int i = 0; i < Hit_MY_Spell_Parent.childCount; i++)
        {
            Hit_MY_Spell.Add(Hit_MY_Spell_Parent.GetChild(i).transform);
        }

    }


    public void InputID(int temp, PlayerInfos Players)
    {
        Skill_ID = new List<int>();
        
        MainImage.color = Color.white;
        ID = temp;
        Live = true;
        Name = CardDataBase.Monster[ID].CardName;

        for (int i = 0; i < Players.MonsterCards.Count; i++)
        {
            if (Players.MonsterCards[i].ID == ID)
            {
                Level = Players.MonsterCards[i].Level;
            }

        }

        Atk = CardDataBase.Monster[ID].ATK;
        UPAtk = CardDataBase.Monster[ID].UpAtk;
        Def = CardDataBase.Monster[ID].DEF;
        UPDef = CardDataBase.Monster[ID].UpDef;
        Hp = CardDataBase.Monster[ID].HP;
        UPHp = CardDataBase.Monster[ID].UpHp;

        //Type = CardDataBase.Monster[ID].Tyep;
        AttackType = CardDataBase.Monster[ID].AttackType;
        AttackEffect = CardDataBase.Monster[ID].AttackEffectNum;
        Based_CriticalPercent = CardDataBase.Monster[ID].CritiaclPercent;
        Based_CriticalDamage = CardDataBase.Monster[ID].CritiaclDamage;

        Setting_Skill_Text();

        BG.sprite = CardDataBase.Monster[ID].BGImage;
        MainImage.sprite = CardDataBase.Monster[ID].Image;

        switch (CardDataBase.Monster[ID].Rank)
        {
            case 3:
                MainImage.material = Shine[0];
                break;
            case 2:
                MainImage.material = Shine[1];
                break;
            case 1:
                MainImage.material = Shine[2];
                break;
            default:
                break;


        }





        Effect_ATK = 0;
        Effect_DEF = 0;
        Effect_HP = 0;

        //Init_Skill();
        //ResetAttackCount();
        CalculatorStatus();
        Current_HP = Current_MAXHP;
        num = 0;

        for (int i = EffectPosi.childCount - 1; i >= 0; i--)
        {
            EffectPosi.GetChild(i).GetComponent<SpellEffect>().DestroyEffect();
        }
        CalculatorStatus();
        

    }
    public void CalculatorStatus()
    {
        Effect_ATK = Effect_DEF = Effect_HP = Effect_Magic_Regi = Effect_CD = Effect_CP = Percent_ATK = Percent_DEF = Percent_MAXHP = 0;

        for (int i = 0; i < EffectPosi.childCount; i++)
        {
            SpellEffect Temp_Effect = EffectPosi.GetChild(i).GetComponent<SpellEffect>();
            Effect_ATK += Temp_Effect.Effect_ATK;
            Effect_DEF += Temp_Effect.Effect_DEF;
            Effect_HP += Temp_Effect.Effect_HP;
            Effect_CP += Temp_Effect.CP;
            Effect_CD += Temp_Effect.CD;
            Percent_ATK += Temp_Effect.Effect_PercentATK;
            Percent_DEF += Temp_Effect.Effect_PercentDEF;
            Percent_MAXHP += Temp_Effect.Effect_PercentHP;
            if (Effect_Magic_Regi < Temp_Effect.Magic_Regi)//������� �������׷¸�����
            {
                Effect_Magic_Regi = Temp_Effect.Magic_Regi;
            }

        }
        Current_ATK = (int)(Mathf.Floor((Atk + (UPAtk * Level)) * ((100f + Percent_ATK) / 100))) + Effect_ATK;
        Current_DEF = (int)(Mathf.Floor((Def + (UPDef * Level)) * ((100f + Percent_DEF) / 100)))+ Effect_DEF;
        Current_MAXHP = (int)(Mathf.Floor((Hp + (UPHp * Level)) * ((100f + Percent_MAXHP) / 100))) + Effect_HP;


        Current_CriticalDamage = Based_CriticalDamage + Effect_CD;
        Current_CriticalPercent = Based_CriticalPercent + Effect_CP;

        if (Current_HP > Current_MAXHP)
        {
            Current_HP = Current_MAXHP;
        }

    }

    private void Update_Bar()
    {
        HP_BAR.fillAmount = Current_HP*1.0f / Current_MAXHP;


    }
    void Init_Skill()
    {

        for(int i=0;i<Skill_ID.Count;i++)
        {
            if (Skill_ID[i] != 0 & SkillDataBase.Skill[Skill_ID[i]].CardType == 1)
            {
                SkillApply(SkillDataBase.Skill[Skill_ID[i]], Skill_ID[i]);
            }
        }

    }

    void Setting_Skill_Text()
    {
        for(int i=0;i< CardDataBase.Monster[ID].Skill_ID.Count;i++)
        {
            Skill_ID.Add(CardDataBase.Monster[ID].Skill_ID[i]);
            
        }
        

    }


    public void Melee_Damaged(int Enemy_Attack)
    {

        Debug.Log("�������ط�" + Enemy_Attack);
        Debug.Log("�������" + Current_DEF);
        if (Current_DEF > 0)
            Enemy_Attack -= Current_DEF;
        animator.SetTrigger("HIT");


        Debug.Log("�������ط�"+Enemy_Attack);



        if (Enemy_Attack > 0)
        {
            //Debug.Log(Enemy_Attack+"��ŭ����������");
            Use_Text(Text_Array.Damaged_T, Enemy_Attack);
            Current_HP -= Enemy_Attack;
            Update_Bar();
        }
        else
        {
            Use_Text(Text_Array.Damaged_T, 0);
        }

    }
    public void Spell_Damaged(int Enemy_Attack,int TYPE=50)//ĳ���Ͱ� ���絥����������
    {


        animator.SetTrigger("HIT");

        if(TYPE!=50)
        {
            Hit_MY_Spell[TYPE].gameObject.SetActive(true);
            StartCoroutine(TurnOff_GameObject(Hit_MY_Spell[TYPE].gameObject,2.0f));
        }


        //Debug.Log("�޴����ط�" + Enemy_Attack);

        if (Effect_Magic_Regi > 0)
        {

            


            Enemy_Attack = Enemy_Attack*(100 - Effect_Magic_Regi) / 100;
            
            //Debug.Log("��������������ط�" + Enemy_Attack);

        }
        
        Use_Text(Text_Array.DamaedSpell_T, Enemy_Attack);
        

        //Debug.Log(Enemy_Attack);
        if (Enemy_Attack > 0)
        {
            //Debug.Log(Enemy_Attack+"��ŭ����������");

            Current_HP -= Enemy_Attack;

        }
        else
        {
            Use_Text(Text_Array.DamaedSpell_T, 0);
        }
        Update_Bar();
    }

    public void DieCheck()
    {
        //Debug.Log("����üũ");
        if (Current_HP <= 0)
        {
            Live = false;
            Current_HP = 0;
            AttackCount = 0;
            Update_Bar();
            MainImage.color = Color.gray;
            MainImage.material = null;

            int L = 0;
            for(int i=0;i<Char_manager.CombatChar.Count;i++)
            {
                if (Char_manager.CombatChar[i].Live)
                    L++;
            }
            if(L==0)
            {
                Enemy_Manager.User_Manager.GameEnd(false);
            }


        }


    }



    public void UsingSpell(SpellCard spell)
    {
        if (Current_MAXHP <= (Current_HP + spell.HEAL))//�ִ�ġ���Ѵ°�� �����ʴ��ѿ����ؼ� ȸ��
        {
            int c = Current_HP + spell.HEAL - Current_MAXHP;
            int t = spell.HEAL - c;
            Current_HP += t;

        }
        else
        {
            Current_HP += spell.HEAL;
        }

        
        Buff_Effect[spell.Value_Char_Effect_Num].gameObject.SetActive(true);
        StartCoroutine(TurnOff_GameObject(Buff_Effect[spell.Value_Char_Effect_Num].gameObject, 3.0f));
        Update_Bar();


        SpellApply(spell);





    }
    public void SkillApply(CharSkillData spell, int Skill_num, int TYPE = 0)
    {

        

        if (spell.Turn == 0)
        {
            SpellEffect e=new SpellEffect();
            e.Apply_Skill_Effect(spell);
        }
        else
        {
            
            SpellEffect e = Instantiate(Temp, EffectPosi);
            e.Init(TYPE, Skill_num);

            //Effect_Use(e, spell.SpellType, spell.Turn, spell.Value,spell.Value_1);
            e.Apply_Skill_Effect(spell);
            //Debug.Log(e.name);
        }
        //ResetAttackCount();//����Ƚ������
    }
    void SpellApply(SpellCard spell, int TYPE = 1)
    {



        if (spell.Turn == 0)
        {
            SpellEffect e = new SpellEffect();
            e.Apply_Spell_Effect(spell);
        }
        else
        {
            SpellEffect e = Instantiate(Temp, EffectPosi);
            e.Init(TYPE, spell.CardNumber);

            //Effect_Use(e, spell.SpellType, spell.Turn, spell.Value,spell.Value_1);
            e.Apply_Spell_Effect(spell);
        }

        //Effect_Use(e,spell.SpellType,spell.Turn,spell.Value,spell.Value_1);
        
    }
    void Effect_Use(SpellEffect e, int Type, int Turn, int Value, int Value_1 = 0)
    {
        switch (Type)
        {
            case 1://����
                //Use_Text(Text_Array.ATK_T, Value);
                break;
            case 2://���
                //Use_Text(Text_Array.DEF_T,Value);
                break;
            case 3://�ִ�ü�¾�

                //e.HP_Effect(Value, Turn);


                //Use_Text(Text_Array.HEAL_T, Value);

                break;
            case 4://����ȸ��

                //e.RegenHP(Value, Turn);

                //Use_Text(Text_Array.HEAL_T, spell.Value);
                break;
            case 5:
                //����Ƚ����?

                //e.AddCount(Value, Turn);
                //Use_Text(Text_Array.ATK_Count_T, Value);
                //ResetAttackCount();//����Ƚ������
                break;
            case 6:
                //e.Setting_Multiple_Effect(Turn, Value, Value_1);
                //Use_Text(Text_Array.ATK_T, Text_Array.DEF_T, Value, Value_1);
                break;
            case 7:
                //e.CP_Effect(Value, Turn);
                //Use_Text(Text_Array.CP_T, Value);

                break;
            case 8:
                //e.CD_Effect(Value, Turn);
                //Use_Text(Text_Array.CP_T, Value);
                break;
            case 9:
                //e.Drew_Effect(Value, Turn);
                break;
            case 10:
                //e.MagicRegi(Value, Turn);
                break;

        }
    }


    void Attack()//���þִϸ��̼��۵��� �۵�
    {
        AttackCount -= 1;
        int num = Random.Range(0, AttackEffect.Count);

        if (AttackType >= 1)
            Enemy_Manager.Melee_Attack(Current_ATK, Current_CriticalPercent, Current_CriticalDamage, num);
        else
            Enemy_Manager.Magic_Attack(Current_ATK, num);

    }


    public void ResetAttackCount()
    {

        int MAX = 1;
        int MIN = 0;
        for (int i = 0; i < EffectPosi.childCount; i++)
        {
            int temp = EffectPosi.GetChild(i).GetComponent<SpellEffect>().Effect_AttackCount;

            if (MAX < temp)
            {

                MAX = temp;
            }
            if (MIN > temp & temp < 0)
            {
                MIN = temp;
            }


        }
        
        AttackCount = 1;
        if (MAX>1)
            AttackCount = MAX;
        if (MIN < 0)
        {
            AttackCount -= MIN;
        }
        //Debug.Log(name + "�ǰ���Ƚ����=" + AttackCount);
    }




    public void TURNUSE()
    {
        for (int i = 0; i < EffectPosi.childCount; i++)
        {
            SpellEffect Temp_Effect = EffectPosi.GetChild(i).GetComponent<SpellEffect>();
            if (Temp_Effect.UsingTurn())
            {
                Temp_Effect.DestroyEffect();
            }
        }
        //ResetAttackCount();
        CalculatorStatus();

    }

    public int MAX_DREW_Count()
    {
        int count = 0;
        for (int i = 0; i < EffectPosi.childCount; i++)
        {
            SpellEffect Temp_Effect = EffectPosi.GetChild(i).GetComponent<SpellEffect>();
            if (Temp_Effect.DrewCount > count)
                count = Temp_Effect.DrewCount;

        }


        return count;
    }


    public void REGEN_Active()
    {
        if (Live)
        {
            int REGEN = 0;
            for (int i = 0; i < EffectPosi.childCount; i++)
            {
                SpellEffect Temp_Effect = EffectPosi.GetChild(i).GetComponent<SpellEffect>();
                REGEN += Temp_Effect.Regen_HP;
            }

            if (REGEN > 0)
            {
                Buff_Effect[Buff_Effect.Count - 1].gameObject.SetActive(true);
                StartCoroutine(TurnOff_GameObject(Buff_Effect[Buff_Effect.Count - 1].gameObject, 2.0f));
                Current_HP += REGEN;
                Use_Text(Text_Array.HEAL_T, REGEN);
            }
            else if (REGEN < 0)
            {
                Current_HP += REGEN;
                Use_Text(Text_Array.Damaged_T, REGEN);
            }
            Update_Bar();
            CalculatorStatus();
        }
    }

    IEnumerator TurnOff_GameObject(GameObject OFF, float time)
    {
        yield return new WaitForSeconds(time);
        OFF.SetActive(false);
    }





    void Use_Text(Text_Array Case, int Value)
    {
        Text_animator[num].SetTrigger("Damage");

        switch (Case)
        {
            case Text_Array.Damaged_T:
                text_mesh[num].color = Color.red;
                text_mesh[num].text = "-" + Value;
                break;
            case Text_Array.HEAL_T:
                text_mesh[num].color = Color.green;
                text_mesh[num].text = "+" + Value;
                break;
            case Text_Array.ATK_T:
                text_mesh[num].color = Color.yellow;
                if (Value > 0)
                    text_mesh[num].text = "+" + Value;
                else
                    text_mesh[num].text = "" + Value;
                break;
            case Text_Array.DEF_T:
                text_mesh[num].color = Color.cyan;
                if (Value > 0)
                    text_mesh[num].text = "+" + Value;
                else
                    text_mesh[num].text = "" + Value;
                break;
            case Text_Array.ATK_Count_T:
                text_mesh[num].color = Color.gray;
                if (Value > 0)
                    text_mesh[num].text = "+" + Value;
                else
                    text_mesh[num].text = "" + Value;
                break;
            case Text_Array.DamaedSpell_T:
                text_mesh[num].color = Color.blue;
                text_mesh[num].text = "-" + Value;
                break;
            case Text_Array.CP_T:
                Color color_CP = new Color();//��ȫ��
                color_CP.r = 1;
                color_CP.g = 0;
                color_CP.b = 1;
                color_CP.a = 1;
                text_mesh[num].color = color_CP;
                text_mesh[num].text = "-" + Value;
                break;
            case Text_Array.CD_T:
                Color color_CD = new Color();//��Ȳ��
                color_CD.r = 1;
                color_CD.g = 127 / 255f;
                color_CD.b = 0;
                color_CD.a = 1;
                text_mesh[num].color = color_CD;
                text_mesh[num].text = "-" + Value;
                break;
            default:
                text_mesh[num].color = Color.black;
                text_mesh[num].text = "+" + Value;
                break;
        }
        num += 1;
        if (text_mesh.Count >= num)
        {
            num = 0;
        }

    }
    void Use_Text(Text_Array Case_1, Text_Array Case_2, int Value, int Value_1)
    {
        StartCoroutine(Double_TextCorountine(Case_1, Case_2, Value, Value_1));

    }
    IEnumerator Double_TextCorountine(Text_Array Case_1, Text_Array Case_2, int value, int value_1)
    {
        Use_Text(Case_1, value);


        yield return new WaitForSeconds(0.3f);
        Use_Text(Case_2, value_1);
    }


    private void OnDisable()
    {
        for (int i = EffectPosi.childCount - 1; i >= 0; i--)
        {
            EffectPosi.GetChild(i).GetComponent<SpellEffect>().DestroyEffect();
        }
        CalculatorStatus();
        transform.position = OriginiPosi;
    }
    private void OnMouseOver()
    {


        Char_manager.CardMouseOver(this);
        CalculatorStatus();


    }
    private void OnMouseExit()
    {

        Char_manager.CardMouseExit(this);

    }
    private void OnMouseDown()
    {

        //manager.CardMouseDown();

    }
    private void OnMouseUp()
    {

        //manager.CardMouseUp();

    }






}
