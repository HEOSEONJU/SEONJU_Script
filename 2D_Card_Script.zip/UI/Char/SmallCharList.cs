using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SmallCharList : MonoBehaviour
{
    public int MYID;
    List<MonsterInfo> Monster;

    
    public void Setting()
    {
        Monster = transform.parent.GetComponent<Charlist>().PlayerMonster.MonsterCards;
    }
    public void ResetState()
    {
        
        bool ck = false;
        for (int i = 0; i < Monster.Count; i++)
        {

            if (Monster[i].ID == MYID)
            {
                ck = true;
                //Debug.Log("����ID" + Monster[i].ID + "/ �ڱ���̵�" + MYID);
            }
        }

        if (ck == true)
        {
            transform.GetChild(2).gameObject.SetActive(false);
        }
        else
        {
            transform.GetChild(2).gameObject.SetActive(true);
        }

    }


}
