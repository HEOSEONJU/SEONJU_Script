using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class V_Result : MonoBehaviour
{
    public ResultScript Result;
    public void DoneAction()
    {
        Result.ViewScore();

    }
    
}
