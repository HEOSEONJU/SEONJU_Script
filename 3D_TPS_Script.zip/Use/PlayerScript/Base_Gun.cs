using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Base_Gun : MonoBehaviour
{

    public Gun_Manager Main;
    public Camera cam;
    public GameObject GunModel;

    public float Delay;//�������������
    protected float Reload; //�ִ�����
    [SerializeField]
    protected float ReloadTime;//�����ð�
    protected float Pack;//����
    public float MAXPack;//�ִ�����
    
    public int GunID = 1;//����ִ� ���� ��ȣ
    [SerializeField]
    protected float GunDistance;
    protected float BoomGunDelay;
    protected float BoomGunMAXDelay;
    protected int GrenadeCount;
    protected int GrenadeMAXCount;
    [SerializeField]
    protected LayerMask layer;
    public float CurrentDelay;//���ǵ�����
    public float CurrentAmmo;
    public float CurrentReload;
    public float CurrentPack;
    [SerializeField]
    protected GameObject FirePosition;
    [SerializeField]
    protected GameObject Pooling;
    [SerializeField]
    protected int GunDamage=200;


    protected int EffectCount=0;

    public  abstract void Shoot();
    public abstract void Reload_Function();





}
