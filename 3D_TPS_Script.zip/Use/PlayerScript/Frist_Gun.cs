using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Frist_Gun : Base_Gun
{

    private void Start()
    {
        Main = GetComponentInParent<Gun_Manager>();
        
    }
    int Fcount;
    public AudioSource[] FLSound;
    public AudioSource[] FHSound;
    public AudioSource[] FirstGunSound;
    int SoundCount;

    public ParticleSystem L1E;
    public override void Shoot()
    {
        if (((Input.GetMouseButton(0) && CurrentAmmo == 0) && CurrentPack >= 1))
        {
            Reload_Function();
        }

        else if (Input.GetMouseButton(0) && Delay <= 0 & CurrentAmmo >= 1)
        {
            Main.PIN = false;
            Delay = CurrentDelay;

            CurrentAmmo -= 1;
            Main.Shooting = true;

            HitGUN1();
            L1E.Play();
            FirstGunSound[Fcount].Play();
            Fcount++;
            if (Fcount == FirstGunSound.Length)
            {
                Fcount = 0;
            }
            Main.ARshot = true;
        }
        else
        {
            Main.ARshot = false;
            Main.Shooting = false;
        }
        if (Main.ARshot == true)
        {
            Main.Recoil = true;
        }
        else
        {
            Main.Recoil = false;
        }
    }
    public override void Reload_Function()
    {
        
        StartCoroutine(ReloadFunction());
    }



    IEnumerator ReloadFunction()
    {

        Main.PIN = false;
        Main.Reloading = true;
        Main.ARRealod = true;
        

        yield return new WaitForSeconds(ReloadTime + 0.3f);

        if (Reload > CurrentPack)
        {
            CurrentAmmo = CurrentPack;
            CurrentPack = 0;
        }
        else
        {
            float temp = CurrentAmmo;
            CurrentAmmo = CurrentReload;
            CurrentPack -= CurrentReload;
            CurrentPack += temp;
        }
        
        Main.ARRealod = false;



        Main.Reloading = false;
    }





    void HitGUN1()
    {
        if (SoundCount >= FLSound.Length)
        {
            SoundCount = 0;
        }

        RaycastHit hitInfo;

        
        if (Physics.Raycast(cam.transform.position, cam.transform.forward, out hitInfo, GunDistance, layer))
        {
            
            Vector3 dir = hitInfo.point - FirePosition.transform.position;
            if (Physics.Raycast(FirePosition.transform.position, dir, out hitInfo, GunDistance, layer))
            {
                
                if (hitInfo.collider.gameObject.layer == 8)
                {

                    EffectCount = GunEffectCount(hitInfo.point, hitInfo.normal, Pooling.transform.gameObject, EffectCount);
                    FLSound[SoundCount].transform.position = hitInfo.transform.position;
                    FLSound[SoundCount].Play();
                    SoundCount++;

                }
                HitHeadShot1(hitInfo);

            }

        }
        Main.Move.GunRecoilActive();
        L1E.Stop();
    }


    int GunEffectCount(Vector3 posi, Vector3 rot, GameObject VE, int EffectCount)
    {
        if (EffectCount >= Pooling.transform.childCount)//40�� Ǯ���ִ밹��ã�Ƽ��ֱ�
        {
            EffectCount = 0;
        }

        ParticleSystem effect;

        effect = VE.transform.GetChild(EffectCount).GetComponent<ParticleSystem>();
        effect.transform.position = posi;
        effect.transform.LookAt(cam.transform.position);
        effect.Play();


        EffectCount++;


        return EffectCount;
    }






    void HitHeadShot1(RaycastHit hitInfo)
    {
        if (hitInfo.transform.CompareTag("Head") & hitInfo.collider.gameObject.layer == 10)
        {
            StartCoroutine(Main.HitCross(0.3f));






            Base_HP temp = hitInfo.transform.GetComponent<Base_HP>();
            if (temp != null)
            {
                if (temp.Armor)
                {

                    FHSound[SoundCount].transform.position = hitInfo.transform.position;
                    FHSound[SoundCount].Play();
                    SoundCount++;
                }
                else
                {
                    FLSound[SoundCount].transform.position = hitInfo.transform.position;
                    FLSound[SoundCount].Play();
                    SoundCount++;
                }

                temp.Damged(GunDamage * 5);



                EffectCount = GunEffectCount(hitInfo.point, hitInfo.normal, Pooling.transform.gameObject, EffectCount);
            }
        }
        else
        {
            
            HitShot1(hitInfo);
        }
    }
    void HitShot1(RaycastHit hitInfo)
    {

        if (hitInfo.transform.CompareTag("hitbox") & hitInfo.collider.gameObject.layer == 10)
        {
            StartCoroutine(Main.HitCross(0.3f));

            



            Base_HP temp = hitInfo.transform.GetComponent<Base_HP>();

            temp.Damged(GunDamage);

            if (temp.Armor)
            {
                FHSound[SoundCount].transform.position = hitInfo.transform.position;
                FHSound[SoundCount].Play();
                SoundCount++;
            }
            else
            {
                FLSound[SoundCount].transform.position = hitInfo.transform.position;
                FLSound[SoundCount].Play();
                SoundCount++;
            }
            EffectCount = GunEffectCount(hitInfo.point, hitInfo.normal, Pooling.transform.gameObject, EffectCount);



        }
        else if (hitInfo.transform.CompareTag("Bullet"))
        {
            StartCoroutine(Main.HitCross(0.3f));


            Base_Bullet temp = hitInfo.transform.GetComponent<Base_Bullet>();

            temp.Damaged(GunDamage);
            if (temp.Armor)
            {
                FHSound[SoundCount].transform.position = hitInfo.transform.position;
                FHSound[SoundCount].Play();
                SoundCount++;
            }
            else
            {
                FLSound[SoundCount].transform.position = hitInfo.transform.position;
                FLSound[SoundCount].Play();
                SoundCount++;
            }
        }
    }
}
